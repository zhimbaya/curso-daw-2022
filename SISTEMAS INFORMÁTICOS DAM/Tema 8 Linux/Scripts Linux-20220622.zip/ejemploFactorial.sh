function PintaFactorial() {
	
	let n=$1	
	
	if [ $n -eq 1 ]
	then			
		echo 1
	else	
		echo `expr $(PintaFactorial $(expr $n-1))\*$n`
	fi	
}

function CalculaFactorial() {
	
	let n=$1	
	
	if [ $n -eq 1 ]
	then			
		echo 1
	else	
		echo `expr $(CalculaFactorial $(expr $n-1)) \* $n`
	fi	
}

echo "Introduce un entero: "
read num	

echo $num"! = " `expr $(PintaFactorial $num)`
	
echo El factorial de $num es `expr $(CalculaFactorial $num)`
