clear
totalFichero=0
while read linea
do
	totalLinea=0
	
	for num in $linea
	do
		let totalLinea=totalLinea+num
	done
	
	echo $totalLinea

	let totalFichero=totalFichero+totalLinea

done < filasNumeros.txt

echo $totalFichero
