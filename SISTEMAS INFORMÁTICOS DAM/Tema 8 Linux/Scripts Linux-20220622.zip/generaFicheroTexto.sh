clear
entrada="algo"
let cta=0
until [ "$entrada" == "fin" ]
do
	let cta=$cta+1
	read -p "Introduce texto: " entrada
	if [ "$entrada" != "fin" ]; then
		echo "$cta. $entrada" >> textoGenerado.txt	
		
	fi

		
done

