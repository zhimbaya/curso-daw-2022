function ValidarDNI() {
	txtDNI=$1
	
	case $txtDNI in
	 [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][A-Z])
		return 1;;
	 *)
		return 0;;
	esac
}

function ValidarDNI_2() {

	longCadena=`expr length $1`
	txtNumeros=`expr substr $1 1 8`
	txtLetra=`expr substr $1 9 1`
	
	if [ $longCadena != 9 ]; then
		echo Número de caracteres indebido
		return 0
	fi

	if [ `expr $txtNumeros : '[0-9]*'` != 8 ]; then
		echo La parte numérica no es adecuada
		return 0
	fi

	if [ `expr $txtLetra : '[A-Z]*'` != 1 ]; then
		echo La letra no es correcta
		return 0
	fi	
	
	return 1
}


read -p "Introduce DNI: " txtDNI

ValidarDNI_2 $txtDNI

if [ $? -eq 1 ]; then
	echo DNI correcto
else
	echo DNI Incorrecto
fi	


