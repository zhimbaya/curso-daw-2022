#!/bin/bash

Sumar () {
	clear
	
	read -p "Introduce un número: " num1
	read -p "Introduce un número: " num2

	let resultado=$num1+$num2
	echo "La suma de ambos es $resultado"

	read -rsp $'Pulse una tecla para continuar...\n' -n1 key
}

Restar () {
	clear

	read -p "Introduce un número: " num1
	read -p "Introduce un número: " num2

	let resultado=$num1-$num2
	echo "La resta de ambos es $resultado"

	read -rsp $'Pulse una tecla para continuar...\n' -n1 key
}

Multiplicar () {
	clear

	read -p "Introduce un número: " num1
	read -p "Introduce un número: " num2

	let resultado=$num1*$num2
	echo "El producto de ambos es $resultado"

	read -rsp $'Pulse una tecla para continuar...\n' -n1 key
}

Dividir () {
	clear

	read -p "Introduce un número: " num1
	read -p "Introduce un número: " num2

	let resultado=$num1/$num2
	echo "La división de ambos es $resultado"

	read -rsp $'Pulse una tecla para continuar...\n' -n1 key
}

while [ "$OPCION" != 5 ]
do
	clear
	
	echo "[1] Suma"
	echo "[2] Resta"
	echo "[3] Multiplicación"
	echo "[4] División"
	echo "[5] Salir"
	read -p "Introduce una opción: " OPCION
	
	case $OPCION in
		1)
			Sumar;;
		2) 
			Restar;;
		3) 
			Multiplicar;;
		4) 
			Dividir;;
		5);;
		*) echo "Opción ingresada invalida, intente de nuevo";;
	esac
done
exit 0

