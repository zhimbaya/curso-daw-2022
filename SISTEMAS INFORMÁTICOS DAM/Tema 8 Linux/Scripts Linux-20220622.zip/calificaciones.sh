#!/bin/bash

read -p "Escribe la nota numérica: " nota


if [ $nota -gt 8 ]; then 
	echo "Sobresaliente"
elif [ $nota -ge 7 ] && [ $nota -le 8 ]; then
	echo "Notable"
elif [ $nota -ge 6 ] && [ $nota -lt 7 ]; then
	echo "Bien"
elif [ $nota -ge 5 ] && [ $nota -lt 6 ]; then
	echo "Suficiente"
elif [ $nota -ge 3 ] && [ $nota -lt 5 ]; then
	echo "Insuficiente"
elif [ $nota -lt 3 ]; then
	echo "Deficiente"
fi


# Usando case
echo "Usando case"
read -p "Escribe la nota numérica: " nota

case $nota in
  	9 | 10)
    		echo "Sobresaliente"
  	;;
	7 | 8)
    		echo "Notable"
  	;;
	6)
    		echo "Bien"
  	;;
	5)
    		echo "Suficiente"
  	;;
  	*)
    		echo "Suspenso"
  	;;
esac


#Para poder utilizar float
read -p "Escribe la nota numérica (separador decimal .): " nota


if (( $(echo "$nota > 8.5" | bc -l) )); then 
	echo "Sobresaliente"
elif (( $(echo "$nota >= 7" | bc -l) && $(echo "$nota < 8.5" | bc -l) )); then
	echo "Notable"
fi


# Usando case
echo "Usando case"
read -p "Escribe la nota numérica (separador decimal .): " nota

case $nota in
  	8.[5-9]* | 9.[0-9]* | 10)
    		echo "Sobresaliente"
  	;;
	7* | 8.[0-4]*)
    		echo "Notable"
  	;;
	6*)
    		echo "Bien"
  	;;
	5*)
    		echo "Suficiente"
  	;;
  	*)
    		echo "Suspenso"
  	;;
esac





