#!/bin/bash

total=0
numLineaEncontrada=0
usuario=""

IngresarDinero(){
		
	echo "En construccion"
}

SacarDinero(){
		
	echo "En construccion"
}

ConsultarSaldo(){
	numLinea=0
	while read Linea ; do	
		j=0
		encontrado=false
		let numLinea=$numLinea+1
		for dato in $Linea; do
			let j=j+1
			if [ $j -eq 1 -a "$dato" = "$usuario"  ]; then
				encontrado=true
			elif [ $j -eq 2 -a "$encontrado" = true ]; then
				total=$dato
			fi
		done
		if [ "$encontrado" = true ]; then
			numLineaEncontrada=$numLinea
			break
		fi		
	done < Saldos.txt

	if [ "$encontrado" = true ]; then
		echo "Su saldo asciende a: $total"
		echo "Encontrado en la linea: $numLineaEncontrada"
		read -rsp $'Pulse una tecla para continuar...\n' -n1 key
	fi
}


while [ "$OPCION" != 5 ]
do
	clear	
	read -p "Introduce tu nombre: " usuario	

	echo "[1] Ingresar dinero"
	echo "[2] Sacar dinero"
	echo "[3] Consultar saldo"
	echo "[4] Crear usuario"
	echo "[5] Salir"
	read -p "Introduce una opción: " OPCION
	
	case $OPCION in
		1)
			IngresarDinero;;
		2) 
			SacarDinero;;
		3) 
			ConsultarSaldo;;
		4) 
			CrearUsuario;;
		5);;
		*) echo "Opción ingresada invalida, intente de nuevo";;
	esac
done
exit 0
