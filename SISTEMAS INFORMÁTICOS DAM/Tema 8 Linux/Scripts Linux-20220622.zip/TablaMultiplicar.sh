#!/bin/bash

read -p "Introduce un número: " num1

ultimo=10
for i in `seq 1 $ultimo`
do
	echo "$i x $num1 = `expr $i \* $num1`"
done
