
Menu() {
	echo "1. Listar"
	echo "2. Nuevo"
	echo "3. Consulta"
	echo "4. Borrar"
	echo "5. Salir"

	read -p "Elige opción: " opt
}

Listar () {
	cat agenda.txt
	read -p "Pulse una tecla para continuar ...." pause
}

Nuevo () {
	read -p "Introduce un nombre: " nomb
	read -p "Introduce un teléfono: " tfno

	echo "$nomb $tfno" >> agenda.txt
}

Consulta () {
	read -p "Introduce un nombre: " nomb
	grep -i "$nomb " agenda.txt
	read -p "Pulse una tecla para continuar ...." pause
}

Borrar () {
	
	read -p "Introduce un nombre: " nomb
	#BuscarLinea $nomb
	#numLinea=$?
	numLinea=$(grep -ni "$nomb" agenda.txt | cut -d: -f1) 
	echo "numLinea: $numLinea"
	read -p "Pulse una tecla para continuar ...." pause

	if [ $numLinea -gt 0 ]
	then
		# sed -i "2d" agenda.txt
		sed -i "$numLinea d" agenda.txt
	else
		echo "El nombre no existe"
		read -p "Pulse una tecla para continuar ...." pause
	fi
}

BuscarLinea () {
	numLinea=0
	numLineaBuscada=0
	echo "Buscoa: $1"
	read -p "Pulse una tecla para continuar ...." pause
	while read linea
	do
		let numLinea=$numLinea+1		
		for pal in $linea
		do
			if [ $1 = $pal ]
			then
				let numLineaBuscada=$numLinea
			fi
		done
	done < agenda.txt
	return $numLineaBuscada
}

opt="0"
while [ $opt != "5" ]
do
	clear	
	Menu
	case "$opt" in 
		"1")
			Listar;;
		"2")
			Nuevo;;
		"3")
			Consulta;;
		"4")
			Borrar;;
		"5")
			echo "Saliendo .....";;
		*)
			echo "Opción no válida";;
	esac
done

