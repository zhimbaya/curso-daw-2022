#!/bin/bash

# Obtener número de caracteres de una cadena sin espacios
a=palabra 
b=`expr $a : '.*'` 
echo $b 

read -p 'Escribe una cadena de caracteres (sin espacios) ' cadena

# Nº de caracteres
echo Número de caracteres `expr $cadena : '.*'`

read -p "Introduce una cadena a buscar: " buscar

# Posición subcadena buscada
posIniBuscar=`expr index "$cadena" "$buscar"`
echo "La cadena buscada está en la posición: " $posIniBuscar 

# Número de caracteres que coinciden al principio de la cadena
echo "Coinciden " `expr match "$cadena" "$buscar"` " caracteres"

# Extraer un número de caracteres desde una posición
echo "4 caracteres desde l posición 1 `expr substr "$cadena" 1 4` "

# Extraer subcadena buscada
numCaracteresBuscar=`expr $buscar : '.*'`
echo "Cadena buscada `expr substr "$cadena" $posIniBuscar $numCaracteresBuscar` "




# Usando otras instrucciones que permiten espacios

# Obtener número de caracteres de una cadena
read -p 'Escribe otra cadena de caracteres ' cadena2
echo 'nº caracteres' ${#cadena2}

# Obtener subcadenas
echo "A partir del carácter 2 tenemos: '${cadena2:2}'"

echo "Los cinco caracteres después del carácter 4 son: " ${cadena2:4:5}


# Reemplazar la primera aparición de una subcadena en la cadena
string='123456789 111123000'
echo ${string/123/ppp}


# Reemplazar todas las apariciones de una subcadena en la cadena
echo ${string//123/XXX}








