#!/bin/bash

while read usu
do
	echo $usu 
	IFS=";"       
	campo=0
	for dato in $usu
        do
		if [ $campo -eq 0 ]; then                
			nombre=$dato
		fi
		if [ $campo -eq 1 ]; then                
			pwd=$dato
		fi
		let campo=campo+1
        done 
	echo "nombre: " $nombre " password: " $pwd

        
	#Comprobar si el usuario existe
	if grep -q "$nombre" /etc/passwd  
	then
		echo "#El usuario " $nombre " ya existe."
		continue
	fi


	#Comprobar si el grupo existe
	if grep -q "$nombre" /etc/group 
	then
		echo "El grupo " $nombre " ya existe."
	else
		addgroup "$nombre"
	fi

	echo "Creando usuario $nombre"
	useradd -g "$nombre" -d /home/"$nombre" -m -s /bin/bash "$nombre"

	echo "Estableciendo contraseña"
	echo "$pwd" | passwd $nombre
	echo "$pwd"

	#echo -e "$nombre:$pwd" | /usr/sbin/chpasswd
	
	# Con este comando hacemos que el usuario creado pertenezca al grupo de usuarios de sudo
	usermod -aG sudo $nombre

	#Crear usuario
	#useradd "$nombre" 
	#echo "$pwd" | passwd $nombre --stdin 
	#echo -e "$nombre:$pwd" | /usr/sbin/chpasswd

	#mkdir /home/$nombre

	#chown $nombre:$nombre -R /home/$nombre

	#chmod 755 -R /home/$nombre
	#usermod -d /home/$nombre $nombre




done <Usuarios.txt

            

