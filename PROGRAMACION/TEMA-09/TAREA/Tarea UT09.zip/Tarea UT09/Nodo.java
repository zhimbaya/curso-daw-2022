package Tema09;

class Nodo {
    
    //Miembros Dato
    Object inf;
    Nodo enlace;

    //Constructor
    public Nodo(Object inf, Nodo enlace) {
        this.inf = inf;
        this.enlace = enlace;
    }
}
