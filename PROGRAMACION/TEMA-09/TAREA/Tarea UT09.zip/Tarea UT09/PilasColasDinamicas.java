/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Tema09;

/**
 *
 * @author diego
 */
public interface PilasColasDinamicas {

    public abstract boolean vacia();

    public abstract void insertar(Object o);

    public abstract Object eliminar();
}
