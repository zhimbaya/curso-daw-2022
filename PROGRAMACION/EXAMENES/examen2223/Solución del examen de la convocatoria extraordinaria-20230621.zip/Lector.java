
package exextra2023;

import java.util.Scanner;


public class Lector {
    
    public static int leerInt()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                return sc.nextInt();
            }
            catch (Exception e)
            {
                sc.nextLine();
            }
        }
    }
    
    public static int leerInt(String s)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(s);
                return sc.nextInt();
            }
            catch (Exception e)
            {
                sc.nextLine();
            }
        }
    }
    
    public static int leerInt(String s, int inf, int sup)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(s);
                int n = sc.nextInt();
                if (n<inf || n>sup)
                    throw new Exception();
                else
                    return n;
            }
            catch (Exception e)
            {
                System.out.println("Valor no válido. El número ha de estar entre "+inf+" y "+sup);
                sc.nextLine();
            }
        }
    }
    
    public static boolean leerSiNo(String s)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(s);
                String linea = sc.nextLine();
                if (linea.length()!=1 || (linea.toLowerCase().charAt(0)!='s' &&
                                          linea.toLowerCase().charAt(0)!='n'))
                    throw new Exception();
                return linea.toLowerCase().equals("s");
            }
            catch (Exception e)
            {
            }
        }
    }
    
    public static String leerLinea(String s)
    {
        Scanner sc = new Scanner(System.in);
       
        System.out.print(s);
        return sc.nextLine();
                
    }
    
}
