
package exextra2023;

import java.io.*;


public class Principal {

    
    public static Dibujo dibujo = null;
    public static boolean guardado = true;
    
    
    public static int menu()
    {
        int op = 0;
        while (op<1 || op>6)
        {
            System.out.println("INDICA QUE DESEAS HACER");
            System.out.println("1. Nuevo dibujo");
            System.out.println("2. Añadir figura");
            System.out.println("3. Mostrar dibujo");
            System.out.println("4. Eliminar figura");
            System.out.println("5. Guardar dibujo");
            System.out.println("6. Salir");
            op = Lector.leerInt();
        }
        return op;
    }
    public static int menuInicio()
    {
        int op = 0;
        while (op<1 || op>2)
        {
            System.out.println("INDICA QUE DESEAS HACER");
            System.out.println("1. Dibujo nuevo");
            System.out.println("2. Abrir dibujo existente desde un fichero");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static int menuFigura()
    {
        int op = 0;
        while (op<1 || op>2)
        {
            System.out.println("INDICA QUE FIGURA DESEAS AÑADIR");
            System.out.println("1. Línea recta");
            System.out.println("2. Arco");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static void crearDibujo()
    {
        dibujo = new Dibujo();
        guardado = false;
    }
    
    public static void abrirDibujo()
    {
        String nf = Lector.leerLinea("Nombre del fichero: ");

        ObjectInputStream ois = null;
        try
        {
            ois = new ObjectInputStream(new FileInputStream(nf));
            dibujo = (Dibujo)ois.readObject();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("El fichero "+nf+" no existe. Se creará un nuevo dibujo.");
            crearDibujo();
        }
        catch (Exception e)
        {
            System.out.println("Error en el fichero. Se creará un nuevo dibujo.");
            crearDibujo();
        }
      
    }
    
    public static void inicio()
    {
        int op = menuInicio();
        if (op==1)
            crearDibujo();
        else
            abrirDibujo();
    }
    
    public static void nuevoDibujo()
    {
        if (!guardado)
        {
            if (Lector.leerSiNo("El dibujo actual no se ha guardado. \n"
                    + "¿Desea guardarlo ahora? (sS/nN) "))
                guardarDibujo();
        }
        crearDibujo();
        guardado = false;
    }
    
    public static void anadirFigura()
    {
        int op = menuFigura();
        if (op==1)
        {
            System.out.println("LINEA");
            Linea l = new Linea();
            dibujo.anadir(l);
        }
        else
        {
            System.out.println("ARCO");
            dibujo.anadir(new Arco());
        }
        guardado = false;
            
    }
   
    
    public static void mostrarDibujo()
    {
        System.out.println(dibujo);
    }
    
    public static void eliminarFigura()
    {
        dibujo.eliminarFigura();
        guardado=false;
    }

    public static void guardarDibujo()
    {
        String f = Lector.leerLinea("Nombre del fichero: ");
        ObjectOutputStream oos = null;
        try
        {
            oos = new ObjectOutputStream(new FileOutputStream(f));
            oos.writeObject(dibujo);
            guardado = true;
        }
        catch (IOException e)
        {
            System.out.println("Error guardando el dibujo");
        }
        finally
        {
            try
            {
                if (oos!=null)
                    oos.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero "+f);
            }
        }
    }
    
    public static void salir()
    {
        if (!guardado)
        {
            if (Lector.leerSiNo("El dibujo actual no se ha guardado. \n"
                    + "¿Desea guardarlo antes de salir? (sS/nN) "))
                guardarDibujo();
        }

    }
    
    public static void main(String[] args) {
        
        inicio();
        int op = menu();
        while (op!=6)
        {
            switch (op)
            {
                case 1: nuevoDibujo();break;
                case 2: anadirFigura(); break;
                case 3: mostrarDibujo();break;
                case 4: eliminarFigura(); break;                
                case 5: guardarDibujo(); break;
            }
            op = menu();
        }
        salir();
        
    }
    
}
