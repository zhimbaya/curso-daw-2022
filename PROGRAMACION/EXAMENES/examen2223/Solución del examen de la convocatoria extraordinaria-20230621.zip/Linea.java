/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exextra2023;

public class Linea extends Figura{
    
    private static final int NPUNTOS = 2;
    
    public Linea()
    {
        super(NPUNTOS);
    }
    
    public String toString()
    {
        return "LINEA: "+super.toString();
    }
    
}
