
package exextra2023;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class Figura implements Serializable{
    
    protected ArrayList<Punto> puntos;
    
    public Figura(int n) //  indica el número de puntos que forman la figura
    {
        puntos = new ArrayList<Punto>();
        for (int i = 1; i <= n; i++)
        {
            System.out.println("Punto"+i);
            puntos.add(new Punto());
        }
    }    
    
    
    @Override
    public String toString()
    {
        String s = "[";
        for (int i = 0; i < puntos.size()-1; i++)
        {
            s+=puntos.get(i)+",";
        }
        if (puntos.size()>=2)
            s+= puntos.get(puntos.size()-1);
        s+="]";
        return s;
    }
    
}
