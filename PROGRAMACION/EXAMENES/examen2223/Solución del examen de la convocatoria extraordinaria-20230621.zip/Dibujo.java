
package exextra2023;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;


public class Dibujo implements Serializable{
    
    private ArrayList<Figura> figuras = null;
    public int ancho, alto;
    
    
    public Dibujo()
    {
        ancho = Lector.leerInt("Ancho: ");
        alto = Lector.leerInt("Alto: ");
        figuras = new ArrayList<Figura>();
    }
    
    public void anadir(Figura f)
    {
        figuras.add(f);
    }
    
    public void listarFiguras()
    {
        for (int i = 0; i < figuras.size(); i++)
        {
            System.out.println(i+" "+figuras.get(i));
        }
            
    }
    
    public void eliminarFigura()
    {
        listarFiguras();
        int i = Lector.leerInt("Figura a eliminar: ");
        if (i>=0 && i<figuras.size())
            figuras.remove(i);
        else
            System.out.println("No existe ninguna figura en la posición "+i);
    }
    
    public int getAncho()
    {
        return ancho;
    }
    
    public int getAlto()
    {
        return alto;
    }
    
    @Override
    public String toString()
    {
        Iterator<Figura> it = figuras.iterator();
        String texto = "DIBUJO "+ancho+"x"+alto+"\n";
        while (it.hasNext())
            texto+=it.next().toString()+"\n";
        return texto;       
    }
    
    
}
