/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exextra2023;

import java.io.Serializable;


public class Punto implements Serializable{
    
    private int x;
    private int y;
    
    public Punto()
    {
        x = Lector.leerInt("x: ",0,Principal.dibujo.getAncho());
        y = Lector.leerInt("y: ",0,Principal.dibujo.getAlto());

    }
    
    @Override
    public String toString()
    {
        return "("+x+","+y+")";
    }
}
