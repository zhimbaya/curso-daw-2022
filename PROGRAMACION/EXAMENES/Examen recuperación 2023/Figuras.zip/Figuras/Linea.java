package Figuras;

/**
 *
 * @author diego
 */
public class Linea extends Figura {

    private Punto p1;
    private Punto p2;

    public Linea(Punto a, Punto b) {
        p1 = a;
        p2 = b;
    }

    public Punto getP1() {
        return p1;
    }

    public Punto getP2() {
        return p2;
    }

}
