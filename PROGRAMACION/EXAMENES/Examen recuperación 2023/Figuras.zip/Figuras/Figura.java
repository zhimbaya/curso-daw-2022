package Figuras;

import java.io.Serializable;

/**
 *
 * @author diego
 */
public abstract class Figura implements Serializable {

    private String nombre;

    public Figura() {
      
    }
}
