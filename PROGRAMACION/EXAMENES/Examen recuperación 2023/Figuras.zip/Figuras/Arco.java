package Figuras;

/**
 *
 * @author diego
 */
public class Arco extends Figura {

    private Punto p1;
    private Punto p2;
    private Punto p3;

    public  Arco(Punto a, Punto b, Punto c) {
        p1 = a;
        p2 = b;
        p3 = c;
    }

    public Punto getP1() {
        return p1;
    }

    public Punto getP2() {
        return p2;
    }

    public Punto getP3() {
        return p3;
    }

    @Override
    public String toString() {
        return "Arco{" + "p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + '}';
    }
    

}
