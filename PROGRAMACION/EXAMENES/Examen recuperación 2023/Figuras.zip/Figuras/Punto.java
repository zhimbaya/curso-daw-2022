package Figuras;

/**
 *
 * @author diego
 */
public class Punto extends Figura {

    private int a;
    private int b;

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public Punto(int x, int y) {
        a = x;
        b = y;
    }

    @Override
    public String toString() {
        return "Punto{" + "a=" + a + ", b=" + b + '}';
    }

}
