package Figuras;

/**
 *
 * @author diego
 */
public class Dibujo extends Figura {

    private int ancho;
    private int alto;

    public Dibujo(int a, int l) {
        ancho = a;
        alto = l;
    }

    @Override
    public String toString() {
        return "Dibujo{" + "ancho=" + ancho + ", alto=" + alto + '}';
    }

}
