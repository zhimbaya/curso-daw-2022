package Figuras;

import java.util.Scanner;

/**
 *
 * @author diego
 */
public class Util {

    public static int leerInt() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            try {
                return sc.nextInt();
            } catch (Exception e) {
                sc.nextLine();
            }
        }
    }

    public static String leerLinea() {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }
}
