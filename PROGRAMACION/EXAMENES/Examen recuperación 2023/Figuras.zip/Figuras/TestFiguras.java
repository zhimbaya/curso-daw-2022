package Figuras;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author diego
 */
public class TestFiguras {

    public static ArrayList<Figura> listaFiguras = new ArrayList<Figura>();
    public static String fichero = "dibujos.bin";

    public static void main(String[] args) {
        cargarDibujo();
        int op = menu();
        while (op != 6) {
            switch (op) {
                case 1:
                    nuevoDibujo(); 
                    break;
                case 2:
                    anadirFigura();
                    break;
                case 3:
                    mostrarFigura();
                    break;
                case 4:
                    eliminarFigura();
                    break;
                case 5:
                    //guardarFigura(); 
                    break;
            }
            op = menu();
        }
        guardarDibujo();
    }

    public static int menu() {
        int op = 0;
        while (op < 1 || op > 6) {
            System.out.println("1. Nuevo dibujo");
            System.out.println("2. Añadir figura");
            System.out.println("3. Mostrar figura");
            System.out.println("4. Eliminar figura");
            System.out.println("5. Guadar figura");
            System.out.println("6. Salir");
            op = Util.leerInt();
        }
        return op;
    }

    public static void cargarDibujo() {
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(fichero));
            listaFiguras = (ArrayList<Figura>) ois.readObject();
        } catch (ClassNotFoundException e) {
            System.out.println("Error en los datos del fichero!");
        } catch (FileNotFoundException e) {
            System.out.println("No hay fichero de productos!");
        } catch (IOException e) {
            System.out.println("Error leyendo el fichero!");
        } catch (Exception e) {
            System.out.println("Error en los datos!");
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException e) {
                System.out.println("Error cerrando el fichero!");
            }
        }
    }

    public static void guardarDibujo() {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(fichero));
            oos.writeObject(listaFiguras);
        } catch (IOException e) {
            System.out.println("Error guardando el fichero!");
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }

            } catch (IOException e) {
                System.out.println("Error cerrando el fichero!");
            }
        }
    }

    public static void nuevoDibujo() {
        System.out.print("Alto: ");
        int c = Util.leerInt();
        System.out.print("Ancho: ");
        int d = Util.leerInt();
        int op = 0;
        while (op!=1 && op!=2)
        {
            System.out.println("¿Desea guardar el Dibujo en un fichero?\n1. Sí\n2.no");
            op = Util.leerInt();
        }
        if (op==1)
        {
            System.out.print("Nombre del fichero: ");
            //guardarFactura(dibujo, Util.leerLinea());
        }
        listaFiguras.add(new Dibujo(c,d));
        
    }

    public static void anadirFigura() {

        System.out.print("Punto1: ");
        int x1 = Util.leerInt();
        int y1 = Util.leerInt();
        Punto p1 = new Punto(x1, y1);
        System.out.print("Punto2: ");
        int x2 = Util.leerInt();
        int y2 = Util.leerInt();
        Punto p2 = new Punto(x2, y2);
        int tipo = 0;
        while (tipo != 1 && tipo != 2) {
            System.out.println("¿linea (1) o arco (2)?");
            tipo = Util.leerInt();
        }
        System.out.print(tipo);
        if (tipo == 1) {
            listaFiguras.add(new Linea(p1, p2));
        } else {
            System.out.print("Punto3: ");
            int x3 = Util.leerInt();
            int y3 = Util.leerInt();
            Punto p3 = new Punto(x3, y3);
            listaFiguras.add(new Arco(p1, p2, p3));
        }
    }

    public static void mostrarFigura() {
        Iterator<Figura> it = listaFiguras.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }

    public static Dibujo buscarFigura(int cod) {
        Iterator<Figura> it = listaFiguras.iterator();
        while (it.hasNext()) {
            Figura p = it.next();
//            if (p.getCodigo() == cod) {
//                return p;
//            }
        }
        return null;
    }

    public static Dibujo eliminarFigura() {
        return null;
    }
}
