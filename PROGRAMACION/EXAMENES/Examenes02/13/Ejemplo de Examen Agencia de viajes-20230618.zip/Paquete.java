/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenord2223;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author anusk
 */
public class Paquete implements Serializable{
    
    private static int contador = 1;
    private int id;
    private String origen;
    private String destino;
    private Transporte trans;
    private Alojamiento aloj;
    private ArrayList<Extra> extras;
    private String fecha;
    private int dias;
    
    public Paquete(String or, String dest, Transporte trans, Alojamiento aloj, 
            ArrayList<Extra> ex, String fech, int d)
    {
        id = contador++;
        origen = or;
        destino = dest;
        this.trans = trans;
        this.aloj = aloj;
        extras = ex;
        fecha = fech;
        dias = d;
    }
    
    public int getId()
    {
        return id;
    }
    
    public static  int getContador()
    {
        return contador;
    }
    
    public static void setContador(int c)
    {
        contador = c;
    }
    
    public double precioTotal()
    {
        double precio = trans.getPrecio()+aloj.getPrecio()*dias;
        Iterator <Extra> it = extras.iterator();
        while (it.hasNext())
            precio+=it.next().getPrecio();
        return precio;
    }
    
    public int durTransporte()
    {
        return trans.getDuracion();
    }
    
    public Transporte getTransporte()
    {
        return trans;
    }
    
    @Override
    public String toString()
    {
        String texto =  "ID: "+id+"\nORIGEN: "+origen+"\nDESTINO: "+destino+
                "\nTRANSPORTE: "+trans+"\nALOJAMIENTO: "+ aloj+ "\nEXTRAS:\n";
        Iterator<Extra> it = extras.iterator();
        while (it.hasNext())
            texto+= "\t"+it.next().toString()+"\n";
        texto+= "FECHA: "+fecha+"\nDIAS: "+dias;
        return texto;
    }
    
}
