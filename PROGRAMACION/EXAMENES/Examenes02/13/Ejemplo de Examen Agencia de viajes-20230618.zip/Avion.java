/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenord2223;

/**
 *
 * @author anusk
 */
public class Avion extends Transporte{
    
    private boolean directo;
    
    public Avion(int d, double p, boolean dir)
    {
        super(d,p);
        directo = dir;
    }
    
    public boolean esDirecto()
    {
        return directo;
    }
    
    @Override
    public String toString()
    {
        return "AVION: "+ super.toString()+""+ ((directo)?"Vuelo directo":"Vuelo con escalas");
    }
    
}
