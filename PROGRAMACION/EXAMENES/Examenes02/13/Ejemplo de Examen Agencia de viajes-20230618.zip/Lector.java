/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenord2223;

import java.util.Scanner;

/**
 *
 * @author anusk
 */
public class Lector {
    
    
    public static int leerInt()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                return sc.nextInt();
            }
            catch (Exception e)
            {
                
            }
        }
    }
    
    public static int leerInt(String p)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(p);
                return sc.nextInt();
            }
            catch (Exception e)
            {
                
            }
        }
    }
    
    public static int leerInt(String p, String err)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(p);
                return sc.nextInt();
            }
            catch (Exception e)
            {
                System.err.println(err);
            }
        }
    }
    
        public static double leerDouble()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                return sc.nextDouble();
            }
            catch (Exception e)
            {
                
            }
        }
    }
    
    public static double leerDouble(String p)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(p);
                return sc.nextDouble();
            }
            catch (Exception e)
            {
                
            }
        }
    }
    
    public static double leerDouble(String p, String err)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(p);
                return sc.nextDouble();
            }
            catch (Exception e)
            {
                System.err.println(err);
            }
        }
    }
    
    public static String leerLinea()
    {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }
    
    public static String leerLinea(String t)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print(t);
        return sc.nextLine();
    }
    
    public static boolean leerSINO()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {               
                String linea = sc.nextLine();
                if (linea.length()!=1 || (linea.toUpperCase().charAt(0)!='S' &&
                        linea.toUpperCase().charAt(0)!='N'))
                    throw new Exception();
                return linea.equalsIgnoreCase("S");
            }
            catch (Exception e)
            {
                
            }
        }
    }
    
    public static boolean leerSINO(String p)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {               
                System.out.print(p);
                String linea = sc.nextLine();
                if (linea.length()!=1 || (linea.toUpperCase().charAt(0)!='S' &&
                        linea.toUpperCase().charAt(0)!='N'))
                    throw new Exception();
                return linea.equalsIgnoreCase("S");
            }
            catch (Exception e)
            {
                
            }
        }
    }
    
    public static boolean leerSINO(String p, boolean err)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {               
                System.out.print(p);
                String linea = sc.nextLine();
                if (linea.length()!=1 || (linea.toUpperCase().charAt(0)!='S' &&
                        linea.toUpperCase().charAt(0)!='N'))
                    throw new Exception();
                return linea.equalsIgnoreCase("S");
            }
            catch (Exception e)
            {
                if (err)
                    System.out.println("DEbe escribir 'n' o 's' en mayúsculas o minúsculas");
            }
        }
    }
    
}
