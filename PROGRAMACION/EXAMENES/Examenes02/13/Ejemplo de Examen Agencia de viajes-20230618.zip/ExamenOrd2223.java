
package examenord2223;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;


public class ExamenOrd2223 {

    public static ArrayList<Paquete> paquetes = new ArrayList<Paquete>();
    public static String fDatos = "paquetes.bin";
    
    public static Extra pedirExtra()
    {
        String desc = Lector.leerLinea("Descripción: ");
        double precio = Lector.leerDouble("Precio: ","Precio inválido, escríbalo de nuevo");
        return new Extra(desc,precio);
    }
    
    public static Alojamiento pedirAlojamiento()
    {
        String nombre = Lector.leerLinea("Nombre: ");
        int dist = Lector.leerInt("Diatancia en metros al centro: ","Distancia inválida");
        double precio = Lector.leerDouble("Precio: ","Precio inválido, escríbalo de nuevo");
        return new Alojamiento(nombre,dist, precio);
    }
    
    public static int menuTransporte()
    {
        int op = 0;
        while (op<1 || op >2)
        {
            System.out.println("1. Avión");
            System.out.println("2. Tren");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static int menuAvion()
    {
        int op = 0;
        while (op<1 || op >2)
        {
            System.out.println("1. Vuelo directo");
            System.out.println("2. Vuelo con escalas");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static Transporte pedirTransporte()
    {
        int tipo = menuTransporte();
        int dur = Lector.leerInt("Duración: ");
        double precio = Lector.leerInt("Precio: ");
        if (tipo == 1)
        {
            int dir = menuAvion();
            return new Avion(dur,precio,dir==1);
        }
        else
            return new Tren(dur,precio);
    }
    

    
    public static void  nuevoPaquete()
    {
        String or = Lector.leerLinea("Origen: ");
        String dest = Lector.leerLinea("Destino: ");
        Transporte t = pedirTransporte();
        Alojamiento al = pedirAlojamiento();
        ArrayList<Extra> extras = new ArrayList<Extra>();
        boolean seguir = Lector.leerSINO("¿Desea añadir algún extra? (sS/nN): ", true);
        while (seguir)
        {
            extras.add(pedirExtra());
            seguir = Lector.leerSINO("¿Desea añadir algún extra más? (sS/nN): ", true);
        }
        
        String fecha = Lector.leerLinea("Fecha: ");
        int dur = Lector.leerInt("Duración del viaje: ");
        
        paquetes.add(new Paquete(or,dest,t,al,extras,fecha,dur));
    }
    
    public static void mostrarPaquetes()
    {
        String fpaquetes = "paquetes.txt";
        BufferedWriter bw = null;
        try
        {
            bw = new BufferedWriter(new FileWriter(fpaquetes));
            
            Iterator <Paquete> it = paquetes.iterator();
            while (it.hasNext())
            {
                Paquete p = it.next();
                System.out.println(p+"\n");
                bw.write(p+"\n\n");
            }
        }
        catch (IOException e)
        {
            System.err.println("Error en el fichero de texto de paquetes");
        }
        finally
        {
            try
            {
                if (bw!=null)
                    bw.close();
            }
            catch (IOException e)
            {
                System.err.println("Error cerrando el fichero de texto");
            }
        }
        
    }
    
    public static void mostrarConFiltro()
    {
        int dur = Lector.leerInt("Indique la duración máxima por trayecto en minutos: ");
        Iterator<Paquete> it = paquetes.iterator();
        while (it.hasNext())
        {
            Paquete p = it.next();
            if (p.durTransporte()<=dur && 
                    ((p.getTransporte() instanceof Avion && ((Avion)p.getTransporte()).esDirecto()) || 
                     (p.getTransporte() instanceof Tren)))
                System.out.println(p+"\n");
        }
    }
    
    public static Paquete buscar(int id)
    {
        Iterator<Paquete> it = paquetes.iterator();
        while (it.hasNext())
        {
            Paquete p = it.next();
            if (p.getId()==id)
                return p;
        }
        return null;
    }
    
    public static void eliminar()
    {
        int id = Lector.leerInt("Identificador: ");
        Paquete p = buscar(id);
        if (p!=null)
            paquetes.remove(p);
        else
            System.out.println("Identificador no encontrado");
    }
    
    public static int menu()
    {
        int op = 0;
        while (op<1 || op >5)
        {
            System.out.println("1. Crear paquete vacacional");
            System.out.println("2. Mostrar y exportar paquetes");
            System.out.println("3. Mostrar paquetes filtrados");
            System.out.println("4. Eliminar paquete");
            System.out.println("5. Salir");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static void guardar()
    {
        ObjectOutputStream oos = null;
        try
        {
            oos = new ObjectOutputStream(new FileOutputStream(fDatos));
            oos.writeObject(paquetes);
            oos.writeInt(Paquete.getContador());
        }
        catch (IOException e)
        {
            System.err.println("Error guardando datos");
        }
        finally
        {
            try
            {
                if (oos!=null)
                    oos.close();
            }
            catch (IOException e)
            {
                System.err.println("Error cerrando el fichero");
            }
        }
    }
    
    
    public static void recuperar()
    {
        ObjectInputStream ois = null;
        try
        {
            ois = new ObjectInputStream(new FileInputStream(fDatos));
            paquetes = (ArrayList<Paquete>)ois.readObject();
            Paquete.setContador(ois.readInt());
        }
        catch (FileNotFoundException e)
        {}
        
        catch (Exception e)
        {
            System.err.println("Error recuperando datos");
        }
        finally
        {
            try
            {
                if (ois!=null)
                    ois.close();
            }
            catch (IOException e)
            {
                System.err.println("Error cerrando el fichero");
            }
        }
    }
    
    public static void main(String[] args) {
        
        recuperar();
        int op = menu();
        while (op!=5)
        {
            switch (op)
            {
                case 1: nuevoPaquete(); break;
                case 2: mostrarPaquetes(); break;
                case 3: mostrarConFiltro(); break;
                case 4: eliminar(); break;
            }
            op = menu();
        }
        guardar();
        
    }
    
}
