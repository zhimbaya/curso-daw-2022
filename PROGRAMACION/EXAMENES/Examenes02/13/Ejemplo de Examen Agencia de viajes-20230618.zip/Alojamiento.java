/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenord2223;

import java.io.Serializable;

/**
 *
 * @author anusk
 */
public class Alojamiento implements Serializable{
    private String nombre;
    private int dist;
    private double precio;
    
    public Alojamiento(String n, int d, double p)
    {
        nombre = n;
        dist = d;
        precio = p;
    }
    
    public double getPrecio()
    {
        return precio;
    }
    
    @Override
    public String toString()
    {
        return nombre+"\n"+dist+" metros hasta el centro\n"+precio+"€/dia";
    }
}
