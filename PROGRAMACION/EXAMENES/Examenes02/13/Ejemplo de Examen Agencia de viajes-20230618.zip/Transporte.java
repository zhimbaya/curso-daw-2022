/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenord2223;

import java.io.Serializable;

/**
 *
 * @author anusk
 */
public abstract class Transporte implements Serializable{
    
    protected int dur;
    protected double precio;
    
    public Transporte(int d, double p)
    {
        dur = d;
        precio = p;
    }
    
    public double getPrecio()
    {
        return precio;
    }
    
    public int getDuracion()
    {
        return dur;
    }
    
    @Override
    public String toString()
    {
        return dur+" min \t"+precio+"€";
    }
    
}
