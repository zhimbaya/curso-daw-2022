/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenord2223;

import java.io.Serializable;

/**
 *
 * @author anusk
 */
public class Extra implements Serializable{
    
    private String desc;
    private double precio;
    
    public Extra (String d, double p)
    {
        desc = d;
        precio = p;
    }
    
    public double getPrecio()
    {
        return precio;
    }
    
    @Override
    public String toString()
    {
        return desc+"\t"+precio+"€";
    }
    
}
