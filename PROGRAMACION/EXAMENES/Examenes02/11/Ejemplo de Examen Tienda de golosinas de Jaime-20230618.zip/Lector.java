
package golosinasjaime;

import java.util.Scanner;


public class Lector {
    
    public static int leerInt()
    {
        Scanner sc = new Scanner(System.in);
        
        while (true)
        {
            try
            {
                return sc.nextInt();
            }
            catch (Exception e)
            {
                System.out.println("Número incorrecto");
                sc.nextLine();
            }
        }
        
    }
    
    public static int leerInt(String texto)
    {
        Scanner sc = new Scanner(System.in);
        
        while (true)
        {
            try
            {
                System.out.print(texto);
                return sc.nextInt();
            }
            catch (Exception e)
            {
                System.out.println("Número incorrecto");
                sc.nextLine();
            }
        }
        
    }
    
    public static double leerDouble()
    {
        Scanner sc = new Scanner(System.in);
        
        while (true)
        {
            try
            {
                return sc.nextDouble();
            }
            catch (Exception e)
            {
                System.out.println("Número incorrecto");
                sc.nextLine();
            }
        }
        
    }
    
    public static double leerDouble(String texto)
    {
        Scanner sc = new Scanner(System.in);
        
        while (true)
        {
            try
            {
                System.out.print(texto);
                return sc.nextDouble();
            }
            catch (Exception e)
            {
                System.out.println("Número incorrecto");
                sc.nextLine();
            }
        }
        
    }
    
    public static String leerLinea()
    {
        Scanner sc = new Scanner(System.in);
        
        return sc.nextLine();
                
    }
    
    public static String leerLinea(String texto)
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.print(texto);
        return sc.nextLine();
                
    }
}
