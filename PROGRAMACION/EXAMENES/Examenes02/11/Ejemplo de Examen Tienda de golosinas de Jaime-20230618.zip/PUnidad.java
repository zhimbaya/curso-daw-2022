
package golosinasjaime;


public class PUnidad extends Producto{
    
    private static final String cod = "PPU";
    
    public PUnidad(String desc, double precio)
    {
        super(cod,desc,precio);
    }
    
    @Override
    public String toString()
    {
        return super.toString()+precio+"€/u";
                
    }
    
}
