
package golosinasjaime;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;


public class GolosinasJaime {
    
    public static ArrayList<Producto> productos = new ArrayList<Producto>();
    public static String fProductos = "productos.bin";
    
    public static int menu()
    {
        int op = 0;
        while (op<1 || op >3)
        {
            System.out.println("1. Registrar producto");
            System.out.println("2. Realizar compra");
            System.out.println("3. Salir");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static int menuProducto()
    {
        int op = 0;
        while (op<1 || op >2)
        {
            System.out.println("1. Producto al peso");
            System.out.println("2. RProducto por unidad");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static void registrar()
    {
        String desc = Lector.leerLinea("Descripción: ");
        double precio = Lector.leerDouble("Precio: ");
        int tipo = menuProducto();
        if (tipo==1)
            productos.add(new PPeso(desc,precio));
        else
            productos.add(new PUnidad(desc,precio));
    }

    public static Producto buscar(String cod)
    {
        Iterator<Producto> it = productos.iterator();
        Producto p = null;
        while (it.hasNext())
        {
            p = it.next();
            if (p.getRef().equals(cod))
                return p;
        }
        return null;
    }
    
    public static void comprar()
    {
        
        String compra = "FACTURA\n-----------\n\n";
        Iterator<Producto> it = productos.iterator();
        System.out.println("LISTA DE PRODUCTOS");
        System.out.println("------------------");
        while (it.hasNext())
            System.out.println(it.next());
        System.out.println("------------------\n");
        
        System.out.println("Indique los productos que desea comprar. Terminar con código 0");
        String cod = Lector.leerLinea("Código: ");
        double precioTotal = 0;
        while (!cod.equals("0"))
        {
            Producto p = buscar(cod);
            if (p!=null)
            {
                if (p instanceof PPeso)
                {
                    int peso = Lector.leerInt("Indique el peso en gramos: ");
                    compra+=((PPeso) p).mostrar(peso)+"\n";
                    precioTotal+=((PPeso) p).calcularPrecio(peso);
                }
                else
                {
                    compra+=p.toString()+"\n";
                    precioTotal+=p.getPrecio();
                }
            }
            cod = Lector.leerLinea("Código: ");
        }
        compra+= "------------------\n";
        compra+= "TOTAL_________________________"+precioTotal+"€\n";
        compra+= "------------------\n";
        
        System.out.println(compra);
        
        String resp = Lector.leerLinea("¿Desea guardar la factura en un fichero? (sS/nN)");
        while (!resp.equalsIgnoreCase("s") && !resp.equalsIgnoreCase("n"))
        {
            resp = Lector.leerLinea("¿Desea guardar la factura en un fichero? (sS/nN)");
        }
        if (resp.equalsIgnoreCase("S"))           
            guardarFactura(compra);
    }

    
    public static void guardarFactura(String c)
    {
        String f = Lector.leerLinea("Indique el nombre del fichero: ");
        
        BufferedWriter bw = null;
        try
        {
            bw = new BufferedWriter(new FileWriter(f));
            bw.write(c);
        }
        catch (IOException e)
        {
            System.out.println("Error generando factura");
        }
        finally
        {
            try
            {
                if (bw!=null)
                    bw.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
        
    }
    
    public static void guardarProductos()
    {
        
        ObjectOutputStream oos = null;
        try
        {
            oos = new ObjectOutputStream(new FileOutputStream(fProductos));
            oos.writeObject(productos);
        }
        catch (IOException e)
        {
            System.out.println("Error guardando los productos");
        }
        finally
        {
            try
            {
                if (oos!=null)
                    oos.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
        
    }
    
    public static void recuperarProductos()
    {
        
        ObjectInputStream ois = null;
        try
        {
            ois = new ObjectInputStream(new FileInputStream(fProductos));
            productos = (ArrayList<Producto>)ois.readObject();
        }
        catch (FileNotFoundException e)
        {
            
        }
        catch (ClassNotFoundException e)
        {
            System.out.println("Contenido erroneo el fichero");
        }
        catch (IOException e)
        {
            System.out.println("Error leyendo los productos");
        }
        catch (Exception e)
        {
            System.out.println("Contenido erroneo el fichero");
        }
        finally
        {
            try
            {
                if (ois!=null)
                    ois.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
        
    }
    
    public static void main(String[] args) {
        
        recuperarProductos();
        int op = menu();
        
        while (op!=3)
        {
            switch (op)
            {
                case 1: registrar(); break;
                case 2: comprar(); break;
            }
            
            op = menu();
            
        }
        
        guardarProductos();
        
    }
    
}
