
package golosinasjaime;

import java.io.Serializable;

public class Referencia implements Serializable{
    
    private String ref;
    private static int cont=1;
    
    public Referencia(String letras)            
    {
        ref = cont+"";
        while (ref.length()<4)
            ref = "0"+ref;
        ref = letras+ref;
        cont++;
    }
    
    public String getRef()
    {
        return ref;
    }    
    
    @Override
    public String toString()
    {
        return ref;
    }
}
