
package golosinasjaime;


public interface AlPeso {
    
    public double calcularPrecio(int gramos);
    
}
