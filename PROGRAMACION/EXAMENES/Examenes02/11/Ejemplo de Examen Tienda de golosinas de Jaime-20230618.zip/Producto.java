
package golosinasjaime;

import java.io.Serializable;


public abstract class Producto implements Serializable{
    
    protected Referencia ref;
    protected String desc;
    protected double precio;
    
    
    
    public Producto (String letras, String desc, double precio)
    {
        ref = new Referencia(letras);
        this.desc = desc;
        this.precio = precio;
    }

    public String getRef() {
        return ref.getRef();
    }

    public double getPrecio() {
        return precio;
    }
    
    @Override
    public String toString()
    {
        return ref+"\t"+desc+"\t";
    }
    
}
