
package golosinasjaime;


public class PPeso extends Producto implements AlPeso{
    
    private static final String cod = "PAP";
    
    public PPeso(String desc, double precio)
    {
        super(cod,desc,precio);
    }
    
    @Override
    public double calcularPrecio(int gramos)
    {
        return gramos*precio/1000;
    }
    
    @Override
    public String toString()
    {
        return super.toString()+precio+"€/Kg";
                
    }
    
    public String mostrar(int gramos)
    {
        return super.toString()+gramos+"gr"+"\t"+calcularPrecio(gramos)+"€";
                
    }
    
}
