/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ordinario2021;

/**
 *
 * @author Profesor
 */
public class VMonodosis extends Vacuna{

    public VMonodosis(String n)
    {
        super(n);
    }
    
}
