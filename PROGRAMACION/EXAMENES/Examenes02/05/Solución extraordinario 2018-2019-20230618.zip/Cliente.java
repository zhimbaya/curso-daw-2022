/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carniceriamanolo;

/**
 *
 * @author anusk
 */
public class Cliente extends Usuario {
    
    public Cliente(String u, String p)
    {
        super(u,p);
    }
    
}
