
package examen3ev22.pkg23;

import java.util.Scanner;


public class Lector {
    
    public static int leerInt()
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                return sc.nextInt();
            }
            catch (Exception e)
            {
                sc.nextLine();
                System.out.println("Número inválido");
            }
        }
    }
    
    public static int leerInt(String msg)
    {
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            try
            {
                System.out.print(msg);
                return sc.nextInt();
            }
            catch (Exception e)
            {
                sc.nextLine();
                System.out.println("Número inválido");
            }
        }
    }
    
    public static String leerLinea()
    {
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }
    
    public static String leerLinea(String msg)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print(msg);
        return sc.nextLine();
    }
    
}
