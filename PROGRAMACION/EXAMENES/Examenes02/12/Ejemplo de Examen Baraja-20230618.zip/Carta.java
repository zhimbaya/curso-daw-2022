
package examen3ev22.pkg23;

import java.io.Serializable;


public class Carta implements Serializable{
    
    private int num;
    private String palo;
    
    public Carta(int n, String p)
    {
        num = n;
        palo = p;
    }

    public int getNum() {
        return num;
    }

    public String getPalo() {
        return palo;
    }
    
    
    
}
