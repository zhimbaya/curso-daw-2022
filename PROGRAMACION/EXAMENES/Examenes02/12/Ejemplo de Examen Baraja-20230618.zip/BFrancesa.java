
package examen3ev22.pkg23;


public class BFrancesa extends Baraja{
    
    private static String[] palos = {"DIAMANTES","PICAS","CORAZONES","TRÉBOLES"};
    private static int nCartas = 13;
    
    public BFrancesa()
    {
        crearBaraja();
    }
    
    @Override
    public void crearBaraja()
    {
        for (int i = 0; i < palos.length; i++)
        {
            for (int j = 1; j <=nCartas;j++)
            {
                baraja.add(new Carta(j,palos[i]));
            }
        }
    }
    
    @Override
    public String nombre(int n)
    {
        switch (n)
        {
            case 1: return "As";
            case 11: return "Jota";
            case 12: return "Reina";
            case 13: return "Rey";
            default: return n+"";
        }
    }
    
}
