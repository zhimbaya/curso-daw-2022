
package examen3ev22.pkg23;


public class BEspaniola extends Baraja{
    
    private static String[] palos = {"OROS","COPAS","ESPADAS","BASTOS"};
    private static int nCartas = 12;
    private boolean ext;
    
    public BEspaniola(boolean e)
    {
        
        ext = e;
        crearBaraja();
    }
    
    @Override
    public void crearBaraja()
    {
        for (int i = 0; i < palos.length; i++)
        {
            for (int j = 1; j <=nCartas;j++)
            {
                if (ext || (j!=8 && j!=9))
                {
                    baraja.add(new Carta(j,palos[i]));
                }
            }
        }
    }
    
    @Override
    public String nombre(int n)
    {
        switch (n)
        {
            case 1: return "As";
            case 10: return "Sota";
            case 11: return "Caballo";
            case 12: return "Rey";
            default: return n+"";
        }
    }
    
}
