
package examen3ev22.pkg23;

import java.io.*;


public class Examen3Ev2223 {

    
    public static Baraja baraja = null;
    
    public static String fBaraja = "baraja.bin";
    
    public static int menu()
    {
        int op = 0;
        while (op < 1 || op >5)
        {
            System.out.println("1. Nueva baraja");
            System.out.println("2. Barajar");
            System.out.println("3. Mostrar baraja");
            System.out.println("4. Imprimir baraja");
            System.out.println("5. Salir");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static int menuBaraja()
    {
        int op = 0;
        while (op < 1 || op >2)
        {
            System.out.println("1. Baraja española");
            System.out.println("2. Baraja francesa");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static int menuEspaniola()
    {
        int op = 0;
        while (op < 1 || op >2)
        {
            System.out.println("1. Extendida (8 y 9");
            System.out.println("2. No extendida");
            op = Lector.leerInt();
        }
        return op;
    }
    
    public static void nuevaBaraja()
    {
        int op = menuBaraja();
        if (op==1)
        {
            boolean ext = (menuEspaniola()== 1);
            baraja = new BEspaniola(ext);
        }
        else
        {
            baraja = new BFrancesa();
        }
    }

    public static void barajar()
    {
        if (baraja == null)
            System.out.println("No hay ninguna baraja creada");
        else
            baraja.barajar();
    }
    
    public static void mostrarBaraja()
    {
        if (baraja == null)
            System.out.println("No hay ninguna baraja creada");
        else
            System.out.println(baraja);
    }
    
    public static void imprimirBaraja()
    {
        if (baraja == null)
            System.out.println("No hay ninguna baraja creada");
        else
            baraja.imprimir();
    }
    
    public static void guardar()
    {
        ObjectOutputStream oos = null;
        try
        {
            oos = new ObjectOutputStream(new FileOutputStream(fBaraja));
            oos.writeObject(baraja);
        }
        catch (IOException e)
        {
            System.out.println("Error guardando baraja");
        }
        finally
        {
            try
            {
                if (oos!=null)
                    oos.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
    }
    
    public static void recuperar()
    {
        ObjectInputStream ois = null;
        try
        {
            ois = new ObjectInputStream(new FileInputStream(fBaraja));
            baraja = (Baraja) ois.readObject();
        }
        catch (FileNotFoundException e)
        {
        }
        catch (Exception e)
        {
            System.out.println("Error recuperando la baraja");
        }
        finally
        {
            try
            {
                if (ois!=null)
                    ois.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
    }
     
    public static void main(String[] args) {
        
        recuperar();
        int op = menu();
        while (op!=5)
        {
            switch (op)
            {
                case 1: nuevaBaraja(); break;
                case 2: barajar(); break;
                case 3: mostrarBaraja(); break;
                case 4: imprimirBaraja(); break;
            }
            op = menu();
        }
        guardar();
        
    }
    
}
