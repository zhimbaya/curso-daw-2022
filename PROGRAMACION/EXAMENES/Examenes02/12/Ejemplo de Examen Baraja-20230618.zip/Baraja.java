
package examen3ev22.pkg23;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public abstract class Baraja implements Serializable{
    
    protected ArrayList<Carta> baraja = new ArrayList<Carta>();
    
    public Baraja()
    {
    }
    
    
    public abstract void crearBaraja();
    
    public void barajar()
    {
        Collections.shuffle(baraja);
    }
    
    public abstract String nombre(int n);
    
    @Override
    public String toString()
    {
        String b="";
        Iterator <Carta> it = baraja.iterator();
        while (it.hasNext())
        {
            Carta c = it.next();
            b+= nombre(c.getNum())+" de "+c.getPalo()+"\n";
        }
        return b;
    }
    
    public void imprimir()
    {
        String fichero = Lector.leerLinea("Nombre del fichero: ");
        BufferedWriter bw = null;
        try
        {
            bw = new BufferedWriter(new FileWriter(fichero));
            bw.write(toString());
        }
        catch (IOException e)
        {
            System.out.println("Error escribiendo el fichero");
        }
        finally
        {
            try
            {
                if (bw!=null)
                    bw.close();
            }
            catch (IOException e)
            {
                System.out.println("Error cerrando el fichero");
            }
        }
    }
}
