/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pendientes2022;

/**
 *
 * @author anusk
 */
public class EOrdinario extends Envio{
    
    public EOrdinario(String nr, String dr, CodigoPostal cr, String nd, String dd, CodigoPostal cd)
    {
        super(nr,dr,cr,nd,dd,cd);
    }
}
