
public class EjemploPMD {

	public static void main(String[] args) {
		EjemploPMD ejemPMD = new EjemploPMD();
		ejemPMD.MetodoDobleReturn();
	}

	public boolean MetodoDobleReturn()
	{
		int iValor = 10;
		
		if(iValor == 5)
		{
			return false;
		}	
		else
		{
			return true;
		}
	}
}
