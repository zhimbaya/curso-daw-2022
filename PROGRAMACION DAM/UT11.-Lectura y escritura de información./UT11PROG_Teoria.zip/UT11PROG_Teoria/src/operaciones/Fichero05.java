package operaciones;

import java.io.File;
/**
* Ejemplo de uso de la clase File
* Listado de los archivos del directorio actual
*
*/
public class Fichero05 {
	public static void main(String[] args) {
		//Creamos un objeto de la clase File indicando la ruta del fichero
		File f = new File("."); // se indica la ruta entre comillas
		// el punto (.) es el directorio actual
		//Mediante el m�todo list() obtenemos la lista de los ficheros del directorio
		String[] listaArchivos = f.list();
		//Recorremos la lista con un for
		for(String nombreArchivo : listaArchivos) {
			System.out.println(nombreArchivo);
		}
	}
}