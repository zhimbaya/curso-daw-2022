package operaciones;

/**
* Paso de argumentos en la l�nea de comandos
* Suma los valores pasados como argumentos
*/
public class Argumentos02 {
	public static void main(String[] args) {
		int suma = 0;
		for (int i = 0; i < args.length; i++) {
			//Convierte a enteros los argumentos
			suma += Integer.parseInt(args[i]);
		}
		System.out.println("La suma de todos los argumentos es: "+suma);
		}
}
