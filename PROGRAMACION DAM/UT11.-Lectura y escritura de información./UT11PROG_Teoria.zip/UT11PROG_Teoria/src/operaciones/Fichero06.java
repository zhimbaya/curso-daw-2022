package operaciones;

import java.io.File;
import java.util.*;
/**
* Ejemplo de uso de la clase File
* Comprobaci�n de existencia y borrado de un fichero
*
*/
public class Fichero06 {
	public static void main(String[] args) {
		Scanner dato=new Scanner(System.in);
		System.out.print("Introduzca el nombre del archivo que desea borrar: ");
		String nombreFichero = dato.next();
		File fichero = new File(nombreFichero);
		//M�todo exists() para verificar la existencia del fichero
		if (fichero.exists()) {
			//M�todo delete de la clase File para borrar fichero
			fichero.delete();
			System.out.println("El fichero se ha borrado correctamente.");
		} else {
			System.out.println("El fichero " + nombreFichero + " no existe.");
		}
		dato.close();
	}
}
