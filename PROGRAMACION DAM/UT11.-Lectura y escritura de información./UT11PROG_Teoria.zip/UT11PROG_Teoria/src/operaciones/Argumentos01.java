package operaciones;
/**
* Paso de argumentos en la l�nea de comandos
*
*/
public class Argumentos01 {
	public static void main(String[] args) {
		System.out.println("Los argumentos introducidos son: ");
		//Con length obtenemos cuantos argumentos hay
		for (int i = 0; i < args.length; i++) {
			//Mostramos cada argumento del array
			System.out.println(args[i]);
	}
	}
}
