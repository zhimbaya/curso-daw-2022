package ficherosbinarios;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Arrays;

/**
 * Implementar un programa que guarde en el fichero socios.dat una tabla de objetos Socio.
 * Despu�s se abrir� de nuevo el fichero en modo lectura para recuperar la tabla de socios,
 * mostr�ndose por pantalla.
 */
public class Ejercicio7 {
	
	public static void main(String[] args) {
		Socio[] tablaSocios=new Socio[4];
		tablaSocios[0]=new Socio(1,"pepe");
		tablaSocios[1]=new Socio(11,"ana");
		tablaSocios[2]=new Socio(7,"juan");
		tablaSocios[3]=new Socio(23,"cris");
		//Mostramos la tabla de socios antes de guardarla
		Arrays.sort(tablaSocios);
		System.out.println(Arrays.toString(tablaSocios));
		//Creamos el flujo de salida binario y escribimos en �l
		try(ObjectOutputStream fsalida=new ObjectOutputStream(new FileOutputStream("socios.dat")))
		{
			fsalida.writeObject(tablaSocios);
			//El flujo de salida se cierra autom�ticamente
		}catch(IOException e) {
			System.out.println(e);
		}
		
	}

}
