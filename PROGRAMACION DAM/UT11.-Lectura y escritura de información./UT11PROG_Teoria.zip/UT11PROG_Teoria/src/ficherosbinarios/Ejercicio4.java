package ficherosbinarios;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * Recuperar la estrofa del archivo cancioPirata.dat y mostrarlo por consola

 */
public class Ejercicio4 {
	public static void main(String[]args) {
		String estrofa;
		try {
			FileInputStream archivo=new FileInputStream("cancionPirata.dat");
			ObjectInputStream flujoSalida=new ObjectInputStream(archivo);
			estrofa=(String)flujoSalida.readObject();
			System.out.println("La estrofa recuperada es: \n");
			System.out.println(estrofa);
			flujoSalida.close();
		}catch(IOException e) {
			System.out.println(e);
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
	}

}
