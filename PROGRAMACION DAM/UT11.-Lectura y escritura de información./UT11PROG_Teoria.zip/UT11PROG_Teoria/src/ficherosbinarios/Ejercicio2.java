package ficherosbinarios;
/**
 * Lee de un archivo datos.dat 10 n�meros enteros, guard�ndolos en un array de tipo entero

 */
import java.io.*;
import java.util.Arrays;
public class Ejercicio2 {
	public static void main(String[] args) {
		//Creo el array 
		int[] t=new int[10];
		try {
			//Defino el flujo del archivo
			FileInputStream archivo=new FileInputStream("datos.dat");
			ObjectInputStream flujoEntrada=new ObjectInputStream(archivo);
			//Voy leyendo cada dato del fichero para almacenarlo en el array
			for (int i=0;i<10;i++) {
				t[i]=flujoEntrada.readInt();
			}
			System.out.println("El contenido del array leido del fichero es:");
			System.out.println(Arrays.toString(t));
			flujoEntrada.close();
		}catch(IOException e) {
			System.out.println("Error de lectura");
		}
		;
	}
}
