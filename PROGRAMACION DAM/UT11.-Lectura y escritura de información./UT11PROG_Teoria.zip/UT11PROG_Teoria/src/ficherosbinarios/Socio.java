package ficherosbinarios;

import java.io.Serializable;


public	class Socio implements Serializable,Comparable<Socio>{
		//Atributos
		int dni;
		String nombre;
		//Constructor
		public Socio(int dni,String nombre) {
			this.dni=dni;
			this.nombre=nombre;
		}
		//M�todos
		public int getdni() {
			return this.dni;
		}
		
		@Override
		public String toString() {
			return "Socio("+"dni= "+dni+", nombre= "+nombre+" )"+"\n";
		}
		
		@Override
		public int compareTo(Socio s) {
			return this.dni-s.getdni();
		}
	}


