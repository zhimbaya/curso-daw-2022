package ficherosbinarios;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * Escribir en un archivo datos.dat los valores de un array de diez enteros
 *
 */
public class Ejercicio1 {
/*Inicializamos el array con los enteros del 0 al 9. Luego crearemos el archivo y le asociamos
 * un flujo de salida de la clase ObjectOutputStream. A continuaci�n, recorremos lel array
 * escribiendo los enteros en �l
 */
 public static void main(String[] args) {
	 //declaro e inicializo el array
	 int[] t= {0,1,2,3,4,5,6,7,8,9};
	 //declaro el objeto flujoSalida y lo inicializo 
	 ObjectOutputStream flujoSalida=null;
	 try {
		 //Flujo de salida de tipo binario asociado al fichero d�nde se van a grabar los datos
		 //Se crear� en disco el arhivo datos.dat. Si ya exist�a, lo borrar� y crear� uno nuevo.
		 flujoSalida=new ObjectOutputStream(new FileOutputStream("datos.dat"));
		 //bucle para escribir el contenido del array 
		 for (int n:t) {
			 //Utilizo el m�todo del flujo de salida para escribir enteros
			 flujoSalida.writeInt(n);
			 
		 }
	//Controlo la excepci�n que puede darse al hacer operaciones de E/S
	 }catch (IOException ex) {
		 System.out.println(ex);
	 }finally {
		 if (flujoSalida != null) {
			 try {
				 flujoSalida.close();
			 }catch (IOException ex) {
				 System.out.println(ex);
			 }
		 }
	 }
	 
	 
 }	
}
