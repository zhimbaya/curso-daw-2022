package ficherosbinarios;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

/**
 * Grabar en el fichero numeros.dat una serie de n�meros enteros no negativos introducidos por
 * teclado. La serie acabar� cuando escribamos -1. Abrir de nuevo numeros.dat para lectura y
 * leer todos los n�meros hasta el final del fichero, mostr�ndolos por pantalla y copi�ndolos
 * en un segundo fichero numerosCopia.dat
 
 */
public class Ejercicio5 {
	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		int numero;
		try {
			FileOutputStream archivoout=new FileOutputStream("numeros.dat");
			ObjectOutputStream flujoSalida=new ObjectOutputStream(archivoout);
			System.out.println("Teclee un n�mero: ");
			numero=sc.nextInt();
			while(numero>=0) {
				flujoSalida.writeInt(numero);
				System.out.println("Teclee un n�mero: ");
				numero=sc.nextInt();
			}
			flujoSalida.close();
		}catch(IOException e) {
			System.out.println(e);
		}
		//Abrimos flujo de entrada para leer del fichero numeros.dat
		//Abrimos el flujo de salida al fichero duplicado numerosCopia.dat
	try (ObjectInputStream fEntrada=new ObjectInputStream(new FileInputStream("numeros.dat"));
		
		ObjectOutputStream fsalida=new ObjectOutputStream(new FileOutputStream("numerosCopia.dat")))
	{
		System.out.println("Los n�meros copiados son: ");
		//bucle que lee de un fichero y copia en el otro..a la vez escribe por pantalla
		//cada n�mero copiado
		while (true) {
			//Leo del fichero de entrada
			numero=fEntrada.readInt();
			//Escribo en el ficheo de salida
			fsalida.writeInt(numero);
			//Escribo por consola
			System.out.println(numero+ " ");
		}	
	
	}catch(EOFException e) {
		System.out.println("Fin del fichero");
	}catch(IOException e) {
		System.out.println(e);
	}
	sc.close();
	
	
	}
}


