package ficherosbinarios;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * Escribe como una cadena, en el fichero binario cacionPirata.dat, la siguiente estrofa:
 * Con diez ca�ones por banda,
 * viento en popa a toda vela,
 * no corta el mar, sino vuela
 * un velero bergant�n.
 * 
 *
 */
public class Ejercicio3 {

	public static void main(String[] args) {
		
		/*Como no se trat de un archivo de texto, convertimos la estrofa en una cadena,
		 * incluyendo los cambios de lina, y luego la escribimos en el lflujo como
		 * un objeto String
		 */

		String estrofa="Con diez ca�ones por banda,\n"
				+"viento en popa a toda vela,\n"
				+"no corta el mar, sino vuela\n"
				+"un velero bergant�n.";
		try {
			FileOutputStream archivo=new FileOutputStream("cancionPirata.dat");
			ObjectOutputStream flujoSalida=new ObjectOutputStream(archivo);
			flujoSalida.writeObject(estrofa);
			flujoSalida.close();
		}catch (IOException e) {
			System.out.println(e);
		}
	/*La estrofa se guardar� con la codificaci�n espec�fica de los objetos de la clase
	 * String y no podremos leerla directamente del archivo con un editor de texto. Si
	 * queremos guardar texto legible con un editor de trexto, deberemos usar archivos de
	 * texto 			
	 */
	}

}
