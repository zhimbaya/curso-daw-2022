package ficheros;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
/**
* Ejemplo de uso de la clase File
* Calcula la media de los n�meros que se encuentran en un fichero de texto
*
*/
public class Fichero02 {
	public static void main(String[] args) {
		Scanner dato=new Scanner(System.in);
		System.out.print("Introduzca el nombre del archivo donde se encuentran los n�meros: ");
		//Introduce fich/numeros.txt ya que es d�nde est� el fichero
		//partiendo del root de tu proyecto
		String nombreFichero =dato.next();
		
		try {
			//Creamos el flujo de datos para leer del fichero
			BufferedReader br = new BufferedReader(new FileReader(nombreFichero));
			String linea = "0";
			int i = 0;
			double suma = 0;
			while (linea != null) {
				i++;
				suma += Double.parseDouble(linea);
				linea = br.readLine();
			}
			i--;
			br.close();
			dato.close();
			System.out.println("La media es " + suma / (double)i);
			} catch (IOException ioe) {
				System.out.println(ioe.getMessage());
			}
		}
}

