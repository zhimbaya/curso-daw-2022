package ficheros;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/**
* Ejemplo de uso de la clase File
* Lectura de un fichero de texto
*
* @
*/
public class Fichero01 {
	public static void main(String[] args) {
		//todas las operaciones de Entrada/Salida tienen que controlar
		//las excepciones
	
		try {
			
			//Creamos un Buffer para leer de un Fichero malaga.txt
			//Miramos la clase FileReader y BufferedReader en la API
			BufferedReader br = new BufferedReader(new FileReader("mifichero.txt"));
			//Creamos una variable linea para guardar cada l�nea que leemos del fichero
			String linea = "";
			//mientras que haya datos � l�neas en el fichero
			while (linea != null) {
				//Escribo la l�nea por pantalla
				System.out.println(linea);
				//Leo la l�nea del fichero con el b�fer
				linea = br.readLine();
			}
			//Cierro el flujo de datos abierto con el fichero
			br.close();
			//Control de las excepciones relacionadas con el fichero
		} catch (FileNotFoundException fnfe) { // qu� hacer si no se encuentra el fichero
			System.out.println("No se encuentra el fichero mifichero.txt");
		} catch (IOException ioe) { // qu� hacer si hay un error en la lectura del fichero
			System.out.println("No se puede leer el fichero mifichero.txt");
		}
		}
		}