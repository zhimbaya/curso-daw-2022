package flujos;

import java.io.FileOutputStream;
import java.io.IOException;

//FileOutputStream
public class Ejemplo1 {
	public static void main(String[]args) {
		byte CR=13;
		byte LF=10;
		try {
			FileOutputStream fos=new FileOutputStream("./fichejemplos/fich1.bin");
			fos.write((byte)'a');
			fos.write((byte)'e');
			fos.write((byte)'i');
			fos.write(CR);
			fos.write(LF);
			fos.write((byte)'o');
			fos.write((byte)'u');
			fos.close();
			System.out.println("Mira en la carpeta fichejemplos, el fichero fich1.bin");
		}catch(IOException e) {
			System.out.println(e);
		}
		
	}

}
