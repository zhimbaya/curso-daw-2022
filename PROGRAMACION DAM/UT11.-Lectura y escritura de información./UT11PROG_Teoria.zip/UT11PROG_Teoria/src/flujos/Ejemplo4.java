package flujos;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class Ejemplo4 {

	public static void main(String[] args) {
		try {
			PrintStream ps;
			FileOutputStream fos=new FileOutputStream("./fichejemplos/fich4.bin");
			//escribiendo en el fichero
			ps=new PrintStream(fos);
			ps.println("Escribiendo en el fichero...");
			ps.println("Escribien en el fichero por segunda vez...");
			ps.close();
			fos.close();
			//escribiendo en consola
			ps=new PrintStream(System.out);
			ps.println("Escribiendo en consola...");
			ps.println("Escribiendo en consola por segunda vez..");
			
		}catch(IOException e) {
			System.out.println(e);
		}

	}

}
