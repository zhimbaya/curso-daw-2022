package flujos;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class Ejemplo7 {

	public static void main(String[] args) {
		try {
			FileInputStream fis=new FileInputStream("./fichejemplos/fich3.bin");
			DataInputStream dis=new DataInputStream(fis);
			System.out.println(dis.readUTF());
			System.out.println(dis.readInt());
			dis.close();
			fis.close();
		}catch(IOException e) {
			System.out.println(e);
		}

	}

}
