package flujos;
//BufferedOutputStream
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ejemplo2 {

	public static void main(String[] args) {
		byte CR=13;
		byte LF=10;
		try {
			FileOutputStream fos=new FileOutputStream("./fichejemplos/fich2.bin");
			BufferedOutputStream bos=new BufferedOutputStream(fos);
			bos.write((byte)'a');
			bos.write((byte)'e');
			bos.write((byte)'i');
			bos.write(CR);
			bos.write(LF);
			bos.write((byte)'o');
			bos.write((byte)'u');
			bos.close();
			System.out.println("Mira en la carpeta fichejemplos, el fichero fich2.bin");
		}catch(IOException e) {
			System.out.println(e);
		}
		

	}

}
