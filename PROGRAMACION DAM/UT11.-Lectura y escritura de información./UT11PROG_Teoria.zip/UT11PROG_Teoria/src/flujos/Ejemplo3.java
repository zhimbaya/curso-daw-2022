package flujos;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ejemplo3 {

	public static void main(String[] args) {
		try {
			FileOutputStream fos=new FileOutputStream("./fichejemplos/fich3.bin");
			DataOutputStream dos=new DataOutputStream(fos);
			String texto="cadena prueba";
			dos.writeUTF(texto);
			int numero=22;
			dos.writeInt(numero);
			System.out.println("Se ha terminado de escribir en el fichero");
			dos.close();
			fos.close();
		}catch(IOException e) {
			System.out.println(e);
		}

	}

}
