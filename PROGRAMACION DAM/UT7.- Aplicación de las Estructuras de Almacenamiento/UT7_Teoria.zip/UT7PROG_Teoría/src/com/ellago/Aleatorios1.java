package com.ellago;

public class Aleatorios1 {
	public static void main(String[] args) {
		System.out.println("Diez n�meros aleatorios:\n");
		for (int i = 1; i < 11; i++) {
			System.out.println(Math.random());
		}
		}
}
