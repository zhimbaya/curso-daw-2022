package com.ellago;

import java.util.*;
public class WHILE_Ejemplo2 {
	public static void main(String[] args) {
		Scanner dato=new Scanner(System.in);
		System.out.println("Por favor, vaya introduciendo n�meros y pulsando INTRO.");
		System.out.println("Para terminar, introduzca un n�mero negativo.");
		int numeroIntroducido = 0;
		int cuentaNumeros = 0;
		int suma = 0;
		while (numeroIntroducido >= 0) {
			numeroIntroducido = dato.nextInt();
			cuentaNumeros++; // Incrementa en uno la variable
			suma += numeroIntroducido; // Equivale a suma = suma + NumeroIntroducido
		}
		System.out.println("Has introducido " + (cuentaNumeros - 1) + " n�meros positivos.");
		System.out.println("La suma total de ellos es " + (suma - numeroIntroducido));
		dato.close();
		}
}


