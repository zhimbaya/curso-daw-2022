package com.ellago;

import java.util.*;
public class IF_Ejemplo2 {
public static void main(String[] args) {
	Scanner dato=new Scanner(System.in);
	System.out.print("�Cu�l es la capital de Kiribati? ");
	String respuesta = dato.next();
	if (respuesta.equals("Tarawa")) {
	System.out.println("�La respuesta es correcta!");
	} else {
	System.out.println("Lo siento, la respuesta es incorrecta.");
	}
	dato.close();
}
}