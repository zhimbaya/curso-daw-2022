package com.ellago;

public class FOR_Ejemplo1 {
	public static void main(String[] args) {
		for (int i = 1; i < 11; i++) {
		System.out.println(i);
		}
		}
}
