package com.ellago;

import java.util.*;

public class IF_Ejemplo1 {
public static void main(String[] args) {
	Scanner dato=new Scanner(System.in);
	System.out.print("�Qu� nota has sacado en el �ltimo examen? (Notaci�n de decimales separados por coma) ");
	double nota=dato.nextDouble();
	if (nota >= 5) {
		System.out.println("�Enhorabuena!, �has aprobado!");
	} else {
		System.out.println("Lo siento, has suspendido.");
	}
	dato.close();
}
}
