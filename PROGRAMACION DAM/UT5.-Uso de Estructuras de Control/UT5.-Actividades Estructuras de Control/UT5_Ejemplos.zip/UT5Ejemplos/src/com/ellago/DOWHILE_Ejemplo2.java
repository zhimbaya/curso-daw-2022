package com.ellago;

import java.util.*;
public class DOWHILE_Ejemplo2 {
	public static void main(String[] args) {
		Scanner dato=new Scanner(System.in);
		int numero;
		do {
			System.out.print("Dime un n�mero: ");
			numero = dato.nextInt();
			if (numero % 2 == 0) {// comprueba si el n�mero introducido es par
				System.out.println("Qu� bonito es el " + numero);
			} else {
				System.out.println("No me gustan los n�meros impares, adi�s.");
			}
		} while (numero % 2 == 0);
		dato.close();
	}
}
		


