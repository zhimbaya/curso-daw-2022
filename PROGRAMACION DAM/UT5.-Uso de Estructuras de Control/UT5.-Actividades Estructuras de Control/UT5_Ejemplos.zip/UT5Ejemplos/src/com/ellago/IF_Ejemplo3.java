package com.ellago;

import java.util.*;
public class IF_Ejemplo3 {
public static void main(String[] args) {
	Scanner dato=new Scanner(System.in);
	System.out.print("Por favor, introduce un n�mero entero: ");
	int x = dato.nextInt();
	if (x < 0) {
		System.out.println("El n�mero introducido es negativo.");
	} else {
		System.out.println("El n�mero introducido es positivo.");
	}
	dato.close();
}
}
