package com.ellago;

import java.util.*;
public class IF_Ejemplo4 {
public static void main(String[] args) {
	Scanner dato=new Scanner(System.in);
	System.out.println("Adivina el n�mero que estoy pensando.");
	System.out.print("Introduce un n�mero entre el 1 y el 100: ");
	int n = dato.nextInt();
	if ((n < 1) || (n > 100)) {
	System.out.println("El n�mero introducido debe estar en el intervalo 1 - 100.");
	System.out.print("Tienes otra oportunidad, introduce un n�mero: ");
	n = dato.nextInt();
	}
	if (n == 24) {
	System.out.println("�Enhorabuena!, �has acertado!");
	} else {
	System.out.println("Lo siento, ese no es el n�mero que estoy pensando.");
	}
	dato.close();
	}
	}
