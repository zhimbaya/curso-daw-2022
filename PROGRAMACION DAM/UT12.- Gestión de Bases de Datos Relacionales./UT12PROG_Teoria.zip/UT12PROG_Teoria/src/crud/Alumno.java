package crud;

import java.util.Date;

public class Alumno {
	//Atributos
	private int id;//atributo identificador
	private String nombre;
	private Date fNacimiento;
	private double notaMedia;
	private String curso; //la cadena curso debe tener una longitud m�xima de 2
	
	//Constructores
	public Alumno(int id) {
		this.id=id;
	}
	public Alumno(int id,String nombre, Date fNacimiento,double notaMedia, String curso) {
		this.id=id;
		this.nombre=nombre;
		this.fNacimiento=fNacimiento;
		this.notaMedia=notaMedia;
		this.curso=curso;
	}
	//M�todos
	public int getId() {
		return this.id;
	}
	public String getNombre() {
		return this.nombre;
	}
	public Date getfNacimiento() {
		return this.fNacimiento;
	}
	public double getnotaMedia() {
		return this.notaMedia;
	}
	public String getcurso() {
		return this.curso;
	}
	public void setId(int id) {
		this.id=id;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public void setfNacimiento(Date fNacimiento) {
		this.fNacimiento=fNacimiento;
	}
	public void setnotaMedia(double notaMedia) {
		this.notaMedia=notaMedia;
	}
	public void setcurso(String curso) {
		this.curso=curso.substring(0, Math.min(2, nombre.length()));//para restringir a 2 caracteres
	}
	@Override
	public String toString() {
		return "Alumno: "+id+"\n"+
				"Nombre: "+nombre+"\n"+
				"Fecha Nacimiento: "+fNacimiento+"\n"+
				"notaMedia: "+notaMedia+"\n"+
				"curso: "+curso+"\n";
	}
}
