package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class AlumnoDAO {
	//Atributos
	private Connection con;
	private final String USUARIO="root";
	private final String PASSWORD="root";
	private final String MAQUINA="localhost";
	private final String BD="Instituto2";
	
	
	//Constructor
	
	 public AlumnoDAO(){
		 //Establecemos conexi�n con la BD
		 this.con=conectar();
	 }
	/*Crea una conexi�n con el SGBD y lo devuelve..La responsabilidad de cerrar la
	 * conexi�n queda en manos de qui�n la use*/
	private Connection conectar() {
	Connection con=null;
	String url="jdbc:mysql://"+MAQUINA+"/"+BD;
		
	try {
		con=DriverManager.getConnection(url,USUARIO,PASSWORD);
	}catch (SQLException e){
		System.out.println(e);
	}
	return con;
	}
	
	/*Este m�todo inserta el objeto this como un registro de la tabla Alumos,
	 * en la BD Instituto2. Debemos hacer coincidir el nombre de los atributos del objeto y el 
	 * de los campos de la tabla*/
	public void create(Alumno alumno) {
		//Si el alumno es null no haremos nada
	if (alumno!=null) {
		
		String sql="INSERT INTO Alumnos (num,nombre,fnac,media,curso)"+
								"VALUES(? ,?,?,?,?)";
		
		try {
			PreparedStatement sentencia=con.prepareStatement(sql);
			sentencia.setInt(1,alumno.getId());
			sentencia.setString(2,alumno.getNombre());
			sentencia.setDate(3, new java.sql.Date(alumno.getfNacimiento().getTime()));
			sentencia.setDouble(4, alumno.getnotaMedia());
			sentencia.setString(5, alumno.getcurso());
			sentencia.executeUpdate();
			
		}catch(SQLException e) {
			System.out.println("Error al insertar "+e);
		}
			
	}
	}
	
	//Lee los datos del alumno con clave id, construye un objeto Alumno con sus
	//datos y lo devuelve
	
	public  Alumno read(int id) {
		Alumno alumno=null;
		String sql="SELECT * FROM Alumnos WHERE num=?";
		try {
			
			PreparedStatement sentencia=con.prepareStatement(sql);
			sentencia.setInt(1, id);
			ResultSet rs=sentencia.executeQuery();
			//Al estar buscando por la clave, solo existen dos alternativas:
			//1.-La encuentra:el resultSet tendr� un �nico registro
			//2.-No la encuentra:el resultSet estar� vac�o
			if (rs.next()) {//si hay un registro
				String nombre=rs.getString("nombre");
				Date fNacimiento=rs.getDate("fNac");
				Double notaMedia=rs.getDouble("media");
				String curso=rs.getString("curso");
				//Creemos un objeto con los datos obtenidos
				alumno=new Alumno(id,nombre,fNacimiento,notaMedia,curso);
						
			}		
		}catch (SQLException e) {
			System.out.println("Error al consultar alumno"+e);
		}
		return alumno;//si no encuentra el id devolver� null
	}
	
	//Actualiza los valores del objeto alumno pasado como par�metro en la BD
	//Supondremos que el objeto ya dispone de su registro.
	//No permitimos que se modifique el identificador de  un objeto.
	public void update(Alumno alumno) {
		if (alumno!=null) {
			String sql="UPDATE Alumnos SET nombre=?,fNac=?,media=?,curso=? WHERE num=?";
			try {
				
				PreparedStatement sentencia=con.prepareStatement(sql);
				sentencia.setString(1, alumno.getNombre());
				sentencia.setDate(2, (java.sql.Date)alumno.getfNacimiento());
				sentencia.setDouble(3, alumno.getnotaMedia());
				sentencia.setString(4,alumno.getcurso());
				sentencia.setInt(5, alumno.getId());//asignamos la clave a buscar
				sentencia.executeUpdate();
				
			}catch (SQLException e) {
				System.out.println("Error al actualizar alumno"+e);
			}
		}
	}
	
	//Eliminamos el registro correspondiente al registro con clave id
	public void delete(int id) {
		String sql="DELETE FROM Alumnos WHERE NUM=?";
		try {
			
			PreparedStatement sentencia=con.prepareStatement(sql);
			sentencia.setInt(1, id);//Asignamos la clave a buscar
			int num=sentencia.executeUpdate();
			if (num!=0) {
				System.out.println("Registro eliminado correctamente");
			}else{
				System.out.println("El alumno no existe");
			};
			
		}catch(SQLException e) {
			System.out.println("Error al eliminar alumno"+e);
		}
			
		}
	}
	

