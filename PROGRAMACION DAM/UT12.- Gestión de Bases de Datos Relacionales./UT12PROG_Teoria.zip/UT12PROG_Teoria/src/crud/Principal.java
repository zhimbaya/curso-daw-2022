package crud;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Principal {
	 static Scanner sc=new Scanner(System.in);
	
	public static void mostrarMenu() {
		System.out.println("BASES DE DATOS DE ALUMNOS");
		System.out.println("=========================");
		System.out.println("1.-Consulta");
		System.out.println("2.-Alta");
		System.out.println("3.-Modificaci�n");
		System.out.println("4.-Baja");
		System.out.println("5.-Salir");
	}
	public static Alumno pedirDatosAlumno()throws ParseException,IOException{
		
		System.out.println("id: ");
		Alumno a=new Alumno(sc.nextInt());
		System.out.println("Nombre: ");
		a.setNombre(sc.next());
		System.out.println("Fecha Nacimiento");
		String fecha=sc.next();
		SimpleDateFormat sd=new SimpleDateFormat("yyyy/MM/dd");
		a.setfNacimiento(sd.parse(fecha));
		System.out.println("Nota Media: ");
		a.setnotaMedia(sc.nextDouble());
		System.out.println("Curso: ");
		a.setcurso(sc.next());
		return a;
		
	}
	public static void main(String[] args) {
		int opcion;
		Alumno a;
		AlumnoDAO dao=new AlumnoDAO();
		try {
			do {
				mostrarMenu();
				System.out.println("Teclee una opci�n...");
				opcion=Integer.parseInt(sc.next());
				switch(opcion) {
				case 1:System.out.println("Teclee la identificaci�n del alumno");
						dao=new AlumnoDAO();
						a=dao.read(sc.nextInt());
						System.out.println(a);
						break;
				case 2: System.out.println("Teclee los datos del alumno...");
						 a=pedirDatosAlumno();
						 dao.create(a);
						 System.out.println("Alumno insertado correctamente");
						break;
				case 3: break;
				case 4: System.out.println("Teclee el id del alumno a eliminar..");
						dao.delete(sc.nextInt());
						System.out.println("Alumno eliminado correctamente");
						break;
				case 5: System.out.println("Saliendo del programa...");
				default: System.out.println("Opci�n inv�lida...");
				}
			}while(opcion!=5);
			sc.close();
		}catch(IOException e) {
			System.out.println("Error de E/S "+e);
		}catch (ParseException e) {
			System.out.println("Error en formato fecha.."+e);
		}

	}

}
