package ejemplos;
/**
 * Ejemplo de una inserci�n parametrizada
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsercionParametrizada {
	public static void main(String[] args) {
		Connection con;
		Scanner sc=new Scanner(System.in);
		String url="jdbc:mysql://localhost:3306/Instituto";
		String usuario="root";
		String password="root";
		try {
			con=DriverManager.getConnection(url,usuario,password);
			System.out.println("Conexi�n realizada correctamente");
			//Pedimos datos
			System.out.println("Introduca el id del alumno:");
			int id=sc.nextInt();
			System.out.println("Introduzca el nombre: ");
			String nombre=sc.next();
			System.out.println("Introduzca la nota media: ");
			Double media=sc.nextDouble();
			
			//Creamos la sentencia sql con los par�metros que necesita
			String sql="INSERT INTO Alumnos VALUES (?,?,?)";
			//Preparo la sentencia con PreparedStatment
			PreparedStatement sentencia=con.prepareStatement(sql);
			//Asigno valores a los par�metros
			sentencia.setInt(1, id);
			sentencia.setString(2, nombre);
			sentencia.setDouble(3, media);
			System.out.println("Se ha insertado "+sentencia.executeUpdate());
			//Cierro conexi�n y flujos
			con.close();
			sc.close();
		
		}catch(SQLException e) {
				System.out.println(e);
		}
			
	}

}
