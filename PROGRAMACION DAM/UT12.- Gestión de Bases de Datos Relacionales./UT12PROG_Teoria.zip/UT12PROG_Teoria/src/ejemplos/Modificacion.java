package ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.sql.Statement;

public class Modificacion {

	public static void main(String[] args) {
		Connection con;
		String url="jdbc:mysql://localhost:3306/Instituto";
		String usuario="root";
		String password="root";
		//Realizo la conexi�n y controlo las excepciones
		try {
			con=DriverManager.getConnection(url,usuario,password);
			System.out.println("Conexi�n realizada correctamente");
			//Creo el Statement
			Statement sentencia=con.createStatement();
			//Realizo la modificaci�n
			String sql="UPDATE Alumnos SET media=media+1";
			//Ejecuta la sentencia de modificaci�n
			System.out.println("El n�mero de filas afectadas es: "+sentencia.executeUpdate(sql));
			
			con.close();
		}catch(SQLTimeoutException e) {
			System.out.println("Excedido el tiempo para conectar a la BBDD");
		}catch(SQLException e) {
			System.out.println("Error en el acceso a la base de datos");
		}

	}

}
