package ejemplos;
import java.sql.*;

public class Conexion {
	public static void main(String[] args) {
		//Con este programa nos conectaremos a la BBDD de Instituto
		//Creo el objeto Connection
		Connection con;
		//Creo el String con el driver, ip, puerto y base de datos para conectar
		String url="jdbc:mysql://localhost:3306/Instituto";
		//Defino el usuario y la password con la que me conecto a la BBDD
		String usuario="root";
		String password="root";
		//Realizo la conexi�n y controlo las excepciones
		try {
			con=DriverManager.getConnection(url,usuario,password);
			System.out.println("Conexi�n realizada correctamente");
			con.close();
		}catch(SQLTimeoutException e) {
			System.out.println("Excedido el tiempo para conectar a la BBDD");
		}catch(SQLException e) {
			System.out.println("Error en el acceso a la base de datos");
		}
		
		
	}

}
