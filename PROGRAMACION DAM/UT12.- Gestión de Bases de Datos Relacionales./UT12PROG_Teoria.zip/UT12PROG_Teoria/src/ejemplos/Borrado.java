package ejemplos;
/**
 * Solicitar el identificador del alumno y eliminarlo de la tabla
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.sql.Statement;
import java.util.Scanner;

public class Borrado {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Connection con;
		String url="jdbc:mysql://localhost:3306/Instituto";
		String usuario="root";
		String password="root";
		//Realizo la conexi�n y controlo las excepciones
		try {
			con=DriverManager.getConnection(url,usuario,password);
			System.out.println("Conexi�n realizada correctamente");
			//Creo el Statement
			Statement sentencia=con.createStatement();
			//Pido el n�mero del alumno
			System.out.println("Introduzca el n�mero del alumno: ");
			int id=sc.nextInt();
			//Realizo la modificaci�n
			String sql="Delete from Alumnos where num="+id;
			//Ejecuta la sentencia de modificaci�n
			System.out.println("El n�mero de filas afectadas es: "+sentencia.executeUpdate(sql));
			
			con.close();
			sc.close();
		}catch(SQLTimeoutException e) {
			System.out.println(e);
		}catch(SQLException e) {
			System.out.println(e);
		}

	}

}
