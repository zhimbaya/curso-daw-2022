package ejemplos;
/**
 * Ejemplo de consulta con sentencia parametrizada
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;

public class Parametrizacion {

	public static void main(String[] args) {
		Connection con;
		String url="jdbc:mysql://localhost:3306/Instituto";
		String usuario="root";
		String password="root";
		//Realizo la conexi�n y controlo las excepciones
		try {
			con=DriverManager.getConnection(url,usuario,password);
			System.out.println("Conexi�n realizada correctamente");
			//Realizo la consulta
			String sql="SELECT * FROM Alumnos where media>?";
			//Preparo la sentencia con PreparedStatement
			PreparedStatement sentencia=con.prepareStatement(sql);
			//Asigno valores a los par�metros con set indicando la posici�n del 
			//par�metro y el valor
			sentencia.setDouble(1, 7.10);
			//Obtengo el resultado
			ResultSet rs=sentencia.executeQuery();
			//Lo muestro
			System.out.println("Nombre Alumno   \t\t\t\t\tMedia");
			System.out.println("=================\t"
					+ "\t\t\t\t=====");
			//El ResultSet contiene el resultado, con next() voy pasando 
			//l�nea a l�nea y obteniendo los datos con get y el nombre de columna
			while(rs.next()) {
				String nombre=rs.getString("nombre");
				Double media=rs.getDouble("media");
				System.out.printf("%-50s%10.2f\n",nombre,media);
				
			}
			//Cierro la conexi�n
			con.close();
		}catch(SQLTimeoutException e) {
			System.out.println("Excedido el tiempo para conectar a la BBDD");
		}catch(SQLException e) {
			System.out.println("Error en el acceso a la base de datos");
		}

	}

}
