package ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.sql.Statement;

public class Seleccion {

	public static void main(String[] args) {
		Connection con;
		String url="jdbc:mysql://localhost:3306/Instituto";
		String usuario="root";
		String password="root";
		//Realizo la conexi�n y controlo las excepciones
		try {
			con=DriverManager.getConnection(url,usuario,password);
			System.out.println("Conexi�n realizada correctamente");
			//Realizo la consulta
			String sql="SELECT nombre,media FROM Alumnos ORDER BY media DESC";
			//Creo la sentencia con Statement para poder mover el cursor hacia atr�s
			Statement sentencia=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
													ResultSet.CONCUR_READ_ONLY);
			//Obtengo el resultado
			ResultSet rs=sentencia.executeQuery(sql);
			//Lo muestro
			System.out.println("Nombre Alumno   \t\t\t\t\tMedia");
			System.out.println("=================\t\t\t\t\t=====");
			//El ResultSet contiene el resultado, con previous() voy pasando 
			//l�nea a l�nea para atr�s y obteniendo los datos con get y el nombre de columna
			while(rs.next()) {
				String nombre=rs.getString("nombre");
				Double media=rs.getDouble("media");
				System.out.printf("%-50s%10.2f\n",nombre,media);
				
			}
			if (rs.first()) {
				String nombre=rs.getString("nombre");
				Double media=rs.getDouble("media");
				System.out.println("El alumno con la nota m�s alta es: "+nombre+" y Nota: "+media);
			}
			if (rs.last()) {
				String nombre=rs.getString("nombre");
				Double media=rs.getDouble("media");
				System.out.println("El alumno con la nota m�s baja es: "+nombre+" y Nota: "+media);
			}
			con.close();
		}catch(SQLTimeoutException e) {
			System.out.println("Excedido el tiempo para conectar a la BBDD");
		}catch(SQLException e) {
			System.out.println(e);
		}


	}

}
