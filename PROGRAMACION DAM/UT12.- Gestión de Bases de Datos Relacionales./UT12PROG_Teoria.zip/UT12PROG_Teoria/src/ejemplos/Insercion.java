package ejemplos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * Realiza una aplicaci�n que solicite todos los datos de un nuevo alumno y los
 * inserte en la base de datos
 *
 */
public class Insercion {

	public static void main(String[] args) {
			Connection con;
			Scanner sc=new Scanner(System.in);
			String url="jdbc:mysql://localhost:3306/Instituto";
			String usuario="root";
			String password="root";
			try {
				con=DriverManager.getConnection(url,usuario,password);
				System.out.println("Conexi�n realizada correctamente");
				//Pedimos datos
				System.out.println("Introduca el id del alumno:");
				int id=sc.nextInt();
				System.out.println("Introduzca el nombre: ");
				String nombre=sc.next();
				System.out.println("Introduzca la nota media: ");
				Double media=sc.nextDouble();
				//Creamos el statement
				Statement sentencia=con.createStatement();
				//Creamos la sentencia sql
				String sql="INSERT INTO Alumnos VALUES ("+id+","+"'"+nombre+"'"+","+"'"+media+"'"+")";
				System.out.println("Se ha insertado "+sentencia.executeUpdate(sql));
				
				con.close();
				sc.close();
			
			}catch(SQLException e) {
					System.out.println(e);
				}
				
				
			}	

}


