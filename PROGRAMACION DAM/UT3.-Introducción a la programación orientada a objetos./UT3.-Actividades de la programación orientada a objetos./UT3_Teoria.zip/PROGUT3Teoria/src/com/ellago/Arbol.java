package com.ellago;

public class Arbol {
	//Atributo
	int altura;
	
	//Constructores
	Arbol () {
		visualizar ("Plantando un reto�o") ;
		altura = 0;
	}
	Arbol (int i) {
		visualizar("Creando un nuevo arbol que tiene " + i +
				" metros de alto");
	altura = i;
	}
	//M�todos
	void info () {
		visualizar("E1 arbol tiene " + altura + " metros de alto");
	}
	void info(String s) {
		visualizar(s + ": El arbol tiene " + altura + 
				"metros de alto");
	}
	static void visualizar (String s) {
		System.out.println (s) ;
	}
 //M�todo principal
	public static void main (String[] args) {
		for(int i = 0; i < 5; i++) {
			Arbol t = new Arbol (i) ;
			t.info();
			t.info ("metodo sobrecargado");
		}
		// Constructor sobrecargado:
		new Arbol() ;
}
}


