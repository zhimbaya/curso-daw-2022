package com.ellago;

public class Perro2 {
	//variable de clase o est�tica que se usa s�lo con m�todos est�ticos
	static int numobjetos=0;
	//atributos
	private Persona due�o;
	private String nombre;
	private String raza;
	
	//constructor
	public Perro2 (Persona due�o,String nombre,String raza) {
	//Actualizo los valores de atributos con los par�metros
		this.due�o=due�o;
		this.nombre=nombre;
		this.raza=raza;
	}
	
	//M�todos de la clase
	public void setDue�o(Persona due�o) {
		this.due�o=due�o;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public void setRaza(String raza) {
		this.raza=raza;
	}
	public Persona getDue�o() {
		return due�o;
	}
	public String getNombre() {
		return nombre;
	}
	public String getRaza() {
		return raza;
	}
	public static int ContadorObjetos() {
		//m�todo est�tico que incrementa una variable est�tica
		return numobjetos++;
	}
	
	//M�todo principal
	public static void main(String[] args) {
		//Defino dos objetos de tipo Persona y otros dos de tipo Perro
		Persona p1,p2;
		Perro2 perro1,perro2;
		
		//Creo los objetos tipo Persona mediante su constructor
		p1=new Persona("Alicia","Su�rez Rodr�guez",34);
		ContadorObjetos();
		p2=new Persona("Juan","Zapatero Olivares",21);
		ContadorObjetos();
		
		//Creo los objetos de tipo Perro mediante su constructor 
		perro1=new Perro2(p1,"Duna","Pastor Alem�n");
		ContadorObjetos();
		perro2=new Perro2(p2,"Maxi","Husky Siberiano");
		//ContadorObjetos();
		perro2.numobjetos++;//aunque accede a la variable, no pertenece al objeto
		
		//Muestro la informaci�n utilizando sus m�todos
		System.out.println("Lista de perros y sus due�os: \n");
		System.out.println("Perro     Raza             Due�o");
		System.out.println("==================================================");
		
		System.out.println(perro1.getNombre()+ "   "+perro1.getRaza()+"     "+
					perro1.due�o.getNombre()+" "+perro1.due�o.getApellidos());
		System.out.println(perro2.getNombre()+ "   "+perro2.getRaza()+"     "+
					perro2.due�o.getNombre()+" "+perro2.due�o.getApellidos());
		
		System.out.println("\n\nEl n�mero de objetos creados es: "+numobjetos);
	}
	
}

