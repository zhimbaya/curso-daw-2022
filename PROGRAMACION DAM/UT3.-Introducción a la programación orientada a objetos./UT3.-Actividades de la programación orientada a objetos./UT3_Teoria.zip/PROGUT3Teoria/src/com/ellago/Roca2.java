package com.ellago;

//Los constructores pueden tener par�metros.
public class Roca2 {
	Roca2 (int i) {
		System.out.println( "Creando la roca numero " + i) ;
	}
public static void main(String[] args) {
	for (int i = 0; i < 10; i++)
		new Roca2 (i);
		}
}



