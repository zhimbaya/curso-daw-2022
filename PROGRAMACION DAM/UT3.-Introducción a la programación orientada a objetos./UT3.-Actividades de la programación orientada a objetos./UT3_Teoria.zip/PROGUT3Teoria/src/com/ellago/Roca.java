package com.ellago;

//Muestra de un constructor simple.
public class Roca {
	Roca() { // �ste es el constructor
		System.out.println("Creando Roca");
	}

	public static void main (String[] args) {
		//variable local
		int i;
		for( i=0; i<10; i++)
			new Roca();
	}
}



