package com.ellago;

public class Persona {
	/*Visibilidad
	private: s�lo visible desde la clase
	public: accesible desde cualquier otra clase
	protected: a nivel de paquete
	Si no se define ning�n tipo es visible a nivel de paquete
	*/
	//atributos de la clase
	private String nombre;
	private String apellidos;
	private int edad;
	
	//constructores
	public Persona (String nombre,String apellidos,int edad) {
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.edad=edad;
		}
	//M�todos de la clase
	public void setNombre(String nombre) {
		this.nombre=nombre; //modifico el atributo nombre
	}
	public void setApellidos(String apellidos) {
		this.apellidos=apellidos;//modifico el atributo apellidos
	}
	public void setEdad(int edad) {
		this.edad=edad;//modifico el atributo edad
	}
	public String getNombre() {
		return this.nombre; //obtengo el valor del nombre
	}
	public String getApellidos() {
		return this.apellidos;//obtengo el valor del atributo apellidos
	}
	public int getEdad() {
		return this.edad;//obtengo el valor del atributo edad
	}
	
	//m�todo principal
	public static void main (String[] args) {
		//Defino tres objetos de la clase Persona
		Persona alum1,alum2,alum3;
		
		//Creo tres instancias u objetos de la clase Persona
		//utilizando su constructor
		alum1=new Persona("Juan","Rodr�guez P�rez",19);
		alum2=new Persona("Leticia", "Moreno Su�rez",20);
		alum3=new Persona("Antonio", "S�inz D�az",22);
		
		//Utilizo los m�todos de la clase aplicados a cada objeto
		
		System.out.println("Los alumnos que tengo son: \n");
		
		//Obtengo los valores de los atributos de cada objeto con su m�todo get
		System.out.println(alum1.getNombre()+" "+alum1.getApellidos()+" "+alum1.getEdad());
		System.out.println(alum2.getNombre()+" "+alum2.getApellidos()+" "+alum2.getEdad());
		System.out.println(alum3.getNombre()+" "+alum3.getApellidos()+" "+alum3.getEdad());
		
		//Modifico los atributos mediante sus m�todos set
		
		alum1.setEdad(21);
		alum2.setApellidos("G�mez Mu�oz");
		alum3.setNombre("Aurelio");
		
		//Muestro los alumnos ya modificados
		System.out.println("\nLos alumnos modificados son: \n");
		
		//Obtengo los valores de los atributos de cada objeto con su m�todo get
		System.out.println(alum1.getNombre()+" "+alum1.getApellidos()+" "+alum1.getEdad());
		System.out.println(alum2.getNombre()+" "+alum2.getApellidos()+" "+alum2.getEdad());
		System.out.println(alum3.getNombre()+" "+alum3.getApellidos()+" "+alum3.getEdad());
		
	}
	
}
