package com.ellago;

public class Coche {
	boolean estadoMotor = false;
	String color;
	String modelo;
	void arrancar(){
		if(estadoMotor == true)
			System.out.println("El coche ya est� arrancado");
		else{
			estadoMotor=true;
			System.out.println("Coche arrancado");
		}
	}
	void detener(){
	if(estadoMotor == false)
		System.out.println("El coche ya est� detenido");
	else{
		estadoMotor=false;
		System.out.println("Coche detenido");
	}
}
public static void main(String args[]){
	Coche ferrari = new Coche();
	//El constructor de java inicializa los atributos no inicializados
	System.out.println(ferrari.color);
	ferrari.color="rojo";
	ferrari.modelo="Diablo";
	System.out.println("El modelo del coche es " +
	ferrari.modelo + " y es de color " + ferrari.color);
	System.out.println("Intentando detener el coche...");
	ferrari.detener();
	System.out.println("Intentando arrancar el coche...");
	ferrari.arrancar();
}
} // fin de la clase Coche.


