package arraylist;

//Necesitamos importar la clase
import java.util.ArrayList;

public class ArrayList01 {
	public static void main(String[] args) {
		//Creamos el ArrayList indicando el tipo de dato que contiene
		ArrayList<String> a = new ArrayList<String>();
		//Consultamos el n�mero de elementos que tiene con el m�todo size()
		System.out.println("N� de elementos: " + a.size());
		//A�adimos elementos con el m�todo add()
		a.add("rojo");
		a.add("verde");
		a.add("azul");
		System.out.println("N� de elementos: " + a.size());
		a.add("blanco");
		System.out.println("N� de elementos: " + a.size());
		//Miramos el contenido de elementos en una posici�n con el m�todo get()
		System.out.println("El elemento que hay en la posici�n 0 es " + a.get(0));
		System.out.println("El elemento que hay en la posici�n 3 es " + a.get(3));
	}
}