package excepcionescontrhow;

public class ExcepcionsinThrow01 {
	public static void main(String[] args) {
		System.out.println("Inicio");
		System.out.println(1 / 0);
		}

}
