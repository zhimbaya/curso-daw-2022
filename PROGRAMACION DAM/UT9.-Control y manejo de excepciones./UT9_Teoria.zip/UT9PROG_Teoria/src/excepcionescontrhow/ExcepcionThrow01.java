package excepcionescontrhow;

public class ExcepcionThrow01 {
	public static void main(String[] args) {
		System.out.println("Inicio");
		throw new ArithmeticException();
		}

}
