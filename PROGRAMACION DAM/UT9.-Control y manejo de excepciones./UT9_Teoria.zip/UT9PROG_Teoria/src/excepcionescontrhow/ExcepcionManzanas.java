package excepcionescontrhow;

import java.util.Scanner;

/*Excepci�n cuando el n�mero de personas es 0*/

public class ExcepcionManzanas {
	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.print("N�mero de manzanas: ");
	int m = Integer.parseInt(s.nextLine());
	System.out.print("N�mero de personas: ");
	int p = Integer.parseInt(s.nextLine());
	System.out.print("A cada persona le corresponden " + reparteManzanas(m, p) + " manzanas.");
	s.close();
	}
	public static int reparteManzanas(int manzanas, int personas) {
	return manzanas / personas;
	}
}