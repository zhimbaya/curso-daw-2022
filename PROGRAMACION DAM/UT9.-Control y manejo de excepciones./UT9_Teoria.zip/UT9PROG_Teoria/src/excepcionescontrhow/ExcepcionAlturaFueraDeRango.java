package excepcionescontrhow;

//clase para crear la excepci�n propia que heredad de la clase Exception
@SuppressWarnings("serial")
public class ExcepcionAlturaFueraDeRango extends Exception {
	public ExcepcionAlturaFueraDeRango(String msg){ 
		super(msg); 
	} 
	
}
