package excepciones;

import java.util.Scanner;
/*Soluciona el control de las Excepciones del ejemplo Excepcion05*/

public class Excepcion06 {
	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Este programa pinta varias l�neas de asteriscos");
	try {
		System.out.print("Introduzca el n�mero total de asteriscos: ");
		int asteriscos = Integer.parseInt(s.nextLine());
		System.out.print("Introduzca el n�mero de l�neas que quiere pintar: ");
		int lineas = Integer.parseInt(s.nextLine());
		int longitud = (asteriscos % lineas) == 0 ? asteriscos / lineas : (int) Math.ceil((double) asteriscos / lineas);
		int cuentaAsteriscos = 0;
		for (int i = 1; i <= lineas; i++) {
			System.out.print("L�nea " + i + ": ");
			for (int j = 0; (j < longitud) && (cuentaAsteriscos++ < asteriscos); j++) {
				System.out.print("*");
			}
		System.out.println();
		}
	} catch (NumberFormatException nfe) {
		System.out.println("Los datos introducidos no son correctos.");
		System.out.println("Se deben introducir n�meros enteros.");
	} catch (ArithmeticException ae) {
		System.out.println("El n�mero de l�neas no puede ser 0.");
	}
	s.close();
}
}
	
