package excepciones;
import java.util.*;
//Prueba introduciendo una cadena de caracteres.
public class Excepcion02 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Este programa calcula la media de dos n�meros");
		try {
			System.out.print("Introduzca el primer n�mero: ");
			double numero1 = Double.parseDouble(s.nextLine());
			System.out.print("Introduzca el segundo n�mero: ");
			double numero2 = Double.parseDouble(s.nextLine());
			System.out.println("La media es " + (numero1 + numero2) / 2);
		} catch (Exception e) {
			System.out.print("No se puede calcular la media. ");
			System.out.println("Los datos introducidos no son correctos.");
		} finally {
			System.out.println("Gracias por utilizar este programa �hasta la pr�xima!");
		}
		s.close();
	}	
}
